﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace DBPrePopSample
{
  public partial class Details : PhoneApplicationPage
  {
    // Data context for the local database
    private RecipeDataContext RecipeDB;

    // Constructor
    public Details()
    {
      InitializeComponent();
      RecipeDB = new RecipeDataContext(RecipeDataContext.DBConnectionString);
    }

    protected override void OnNavigatedTo(
      System.Windows.Navigation.NavigationEventArgs e)
    {
      int id = Convert.ToInt16(NavigationContext.QueryString["id"]);
      if (RecipeDB.DatabaseExists())
      {
        //Grab all of the recipes from the Recipe database
        var selectedRecipe = from Recipe recipe in RecipeDB.Recipes
                             where recipe.RecipeId == id
                             select recipe;

        this.DataContext = selectedRecipe.First<Recipe>();
      }
      base.OnNavigatedTo(e);
    }

    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (RecipeDB.DatabaseExists())
      {
        //Commit changes if moving from page
        RecipeDB.SubmitChanges();
      }
      base.OnNavigatedFrom(e);
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    // Used to notify Silverlight that a property has changed.
    private void NotifyPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }
    #endregion

  }
}