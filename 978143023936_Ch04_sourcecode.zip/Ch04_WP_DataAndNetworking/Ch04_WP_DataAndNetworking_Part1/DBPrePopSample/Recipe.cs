﻿using System;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using Microsoft.Phone.Data.Linq.Mapping;

namespace DBPrePopSample
{
  [Table,Index(Columns = "Name ASC", Name="IDX_Name")]
  public class Recipe : INotifyPropertyChanged, INotifyPropertyChanging
  {
    public Recipe()
    {
    }

    // Define ID: private field, public property, and database column.
    private int _recipeId;
    [Column(DbType = "INT NOT NULL IDENTITY", IsDbGenerated = true,
     IsPrimaryKey = true, CanBeNull = false, AutoSync = AutoSync.OnInsert)]
    public int RecipeId
    {
      get { return _recipeId; }
      set
      {
        NotifyPropertyChanging("RecipeId");
        _recipeId = value;
        NotifyPropertyChanged("RecipeId");
      }
    }

    private string _name;
    [Column]
    public string Name
    {
      get { return _name; }
      set
      {
        if (_name != value)
        {
          NotifyPropertyChanging("Name");
          _name = value;
          NotifyPropertyChanged("Name");
        }
      }
    }

    private string _cookingTime;
    [Column]
    public string CookingTime
    {
      get { return _cookingTime; }
      set
      {
        if (_cookingTime != value)
        {
          NotifyPropertyChanging("CookingTime");
          _cookingTime = value;
          NotifyPropertyChanged("CookingTime");
        }
      }
    }

    private MealType _mealType;
    [Column]
    public MealType MealType
    {
      get { return _mealType; }
      set
      {
        if (_mealType != value)
        {
          NotifyPropertyChanging("MealType");
          _mealType = value;
          NotifyPropertyChanged("MealType");
        }
      }
    }

    private string _ingredients;
    [Column]
    public string Ingedients
    {
      get { return _ingredients; }
      set
      {
        if (_ingredients != value)
        {
          NotifyPropertyChanging("Ingedients");
          _ingredients = value;
          NotifyPropertyChanged("Ingedients");
        }
      }
    }

    private string _steps;
    [Column]
    public string Steps
    {
      get { return _steps; }
      set
      {
        if (_steps != value)
        {
          NotifyPropertyChanging("Steps");
          _steps = value;
          NotifyPropertyChanged("Steps");
        }
      }
    }

    [Column(IsVersion = true)]
    private Binary _version;

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    // Used to notify the page that a data context property changed
    private void NotifyPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }

    #endregion

    #region INotifyPropertyChanging Members

    public event PropertyChangingEventHandler PropertyChanging;

    // Used to notify the data context that a data context property is about to change
    private void NotifyPropertyChanging(string propertyName)
    {
      if (PropertyChanging != null)
      {
        PropertyChanging(this, new PropertyChangingEventArgs(propertyName));
      }
    }

    #endregion
  }

  public enum MealType
  {
    Breakfast, Lunch, Dinner, Dessert
  }

  public class RecipeDataContext : DataContext
  {
    //Using static makes the connection string available anywhere in the code
    //but let's us keep it close to where it is used within the code
    public static string DBConnectionString = "Data Source=isostore:/Recipes.sdf";

    public RecipeDataContext(string connectionString)
      : base(connectionString)
    { }

    public Table<Recipe> Recipes;
  }
}