﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using Microsoft.Phone.Controls;


namespace DbCreateSample
{
  public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
  {
    // Data context for the local database
    private RecipeDataContext RecipeDB;

    // Define an observable collection property that controls can bind to.
    private ObservableCollection<Recipe> _recipeItems;
    public ObservableCollection<Recipe> RecipeItems
    {
      get
      {
        return _recipeItems;
      }
      set
      {
        if (_recipeItems != value)
        {
          _recipeItems = value;
          NotifyPropertyChanged("RecipeItems");
        }
      }
    }

    // Constructor
    public MainPage()
    {
      InitializeComponent();
      RecipeDB = new RecipeDataContext(RecipeDataContext.DBConnectionString);
      this.DataContext = this;
    }

    protected override void OnNavigatedTo(
      System.Windows.Navigation.NavigationEventArgs e)
    {
      if (RecipeDB.DatabaseExists())
      {
        //Grab all of the recipes from the Recipe database
        var recipesFromDb = from Recipe recipe in RecipeDB.Recipes
                            select recipe;
        //Instantiate the RecipeItems collection with the database items
        //This is the collection that we actually work with in code or via 
        //databinding visually with Blend
        RecipeItems = new ObservableCollection<Recipe>(recipesFromDb);

        textNumRecords.Text = RecipeItems.Count + " " + textNumRecords.Text;
      }
      base.OnNavigatedTo(e);
    }

    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (RecipeDB.DatabaseExists())
      {
        //Commit changes if moving from page
        RecipeDB.SubmitChanges();
      }
      base.OnNavigatedFrom(e);
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    // Used to notify Silverlight that a property has changed.
    private void NotifyPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }
    #endregion
  }

}