﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using System.Linq;
using System.Collections.Generic;

namespace LongListSelectorSample.pages
{
  public partial class LongListSelectorPage2 : PhoneApplicationPage
  {
    public LongListSelectorPage2()
    {
      InitializeComponent();
    }

    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
    }
  }
}