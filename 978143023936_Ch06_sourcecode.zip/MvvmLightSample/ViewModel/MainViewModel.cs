﻿using GalaSoft.MvvmLight;
using MvvmLightSample.Model;

namespace MvvmLightSample.ViewModel
{
  /// <summary>
  /// This class contains properties that the main View can data bind to.
  /// <para>
  /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
  /// </para>
  /// <para>
  /// See http://www.galasoft.ch/mvvm/getstarted
  /// </para>
  /// </summary>
  public class MainViewModel : ViewModelBase
  {
    private readonly IDataService _dataService;

    public const string ApplicationTitlePropertyName = "ApplicationTitle";
    private string _applicationTitle = string.Empty;
    public string ApplicationTitle
    {
      get
      {
        return _applicationTitle;
      }

      set
      {
        if (_applicationTitle == value)
        {
          return;
        }

        _applicationTitle = value;
        RaisePropertyChanged(ApplicationTitle);
      }
    }

    public const string PageTitlePropertyName = "PageTitle";
    private string _pageTitle = string.Empty;
    public string PageName
    {
      get
      {
        return _pageTitle;
      }

      set
      {
        if (_pageTitle == value)
        {
          return;
        }

        _pageTitle = value;
        RaisePropertyChanged(PageTitlePropertyName);
      }
    }

    /// <summary>
    /// Initializes a new instance of the MainViewModel class.
    /// </summary>
    public MainViewModel(IDataService dataService)
    {
      _dataService = dataService;
      _dataService.GetApplicationTitle(
          (item, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }

            ApplicationTitle = item.Title;
          });

      _dataService.GetPageName(
          (item, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }

            PageName = item.Title;
          });
    }

    ////public override void Cleanup()
    ////{
    ////    // Clean up if needed

    ////    base.Cleanup();
    ////}
  }
}