﻿using System.Collections.ObjectModel;
using System.Linq;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using MvvmLightSample.Model;

namespace MvvmLightSample.ViewModel
{
  public class VendorsViewModel : ViewModelBase
  {
    private readonly IVendorsService _vendorsService;

    public const string VendorsPropertyName = "Vendors";
    private ObservableCollection<Vendor> _vendors = null;
    public ObservableCollection<Vendor> Vendors
    {
      get
      {
        return _vendors;
      }

      set
      {
        if (_vendors == value)
        {
          return;
        }

        _vendors = value;
        RaisePropertyChanged(VendorsPropertyName);
      }
    }

    /// <summary>
    /// Initializes a new instance of the VendorsViewModel class.
    /// </summary>
    public VendorsViewModel(IVendorsService dataService)
    {
      _vendorsService = dataService;

      Vendors = new ObservableCollection<Vendor>();
      _vendorsService.GetVendors(
          (vendors, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            Vendors = (ObservableCollection<Vendor>)vendors;
          });

      //Instantiate Commands
      AddAVendorCommand = new RelayCommand(
        () => AddVendor());

      RemoveAVendorCommand = new RelayCommand<Vendor>(
        param => RemoveVendor(param));

    }

    #region Business Logic
    public Vendor GetVendorByAccountNumber(string accountNumber)
    {
      var vendor = from v in Vendors
                   where v.AccountNumber == accountNumber
                   select v;

      return vendor.First<Vendor>();
    }

    public void AddVendor()
    {
      Vendors.Add(new Vendor()
      {
        AccountNumber = "111111",
        CreditRating = 65,
        Name = "Fabrikam Bikes - Added"
      });
    }

    public void RemoveVendor(object vendor)
    {
      if (null != vendor)
        Vendors.Remove((Vendor)vendor);
    }
    #endregion

    #region Commanding
    public RelayCommand AddAVendorCommand
    {
      get;
      private set;
    }

    public RelayCommand<Vendor> RemoveAVendorCommand
    {
      get;
      private set;
    }
    #endregion

    ////public override void Cleanup()
    ////{
    ////    // Clean up if needed

    ////    base.Cleanup();
    ////}
  }
}