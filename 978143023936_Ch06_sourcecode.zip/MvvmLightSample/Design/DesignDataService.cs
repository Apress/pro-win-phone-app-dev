﻿using System;
using MvvmLightSample.Model;

namespace MvvmLightSample.Design
{
  public class DesignDataService : IDataService
  {
    public void GetApplicationTitle(Action<DataItem, Exception> callback)
    {
      // Use this to create design time data

      var item = new DataItem("CHAPTER SIX");
      callback(item, null);
    }

    public void GetPageName(Action<DataItem, Exception> callback)
    {
      // Use this to create design time data

      var item = new DataItem("mvvm light sample");
      callback(item, null);
    }
  }
}