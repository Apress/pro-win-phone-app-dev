﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using MvvmLightSample.Model;

namespace MvvmLightSample.Design
{
  public class DesignVendorService : IVendorsService
  {
    public void GetVendors(Action<IList<Vendor>, Exception> callback)
    {
      var item = new ObservableCollection<Vendor>(){new Vendor()
      {
        AccountNumber = "111111",
        CreditRating = 65,
        Name = "Fabrikam Bikes111"
      },
      new Vendor()
      {
        AccountNumber = "222222",
        CreditRating = 45,
        Name = "Contoso Bikes222"
      },
      new Vendor()
      {
        AccountNumber = "333333",
        CreditRating = 45,
        Name = "Contoso Bikes333333"
      },
      
      new Vendor()
      {
        AccountNumber = "444444",
        CreditRating = 45,
        Name = "Contoso Bikes444"
      },
      new Vendor()
      {
        AccountNumber = "555555",
        CreditRating = 75,
        Name = "Duwamish Bikes555"
      }};

      callback(item, null);
    }
  }
}