﻿using Microsoft.Phone.Controls;

namespace MvvmLightSample
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }
  }
}
