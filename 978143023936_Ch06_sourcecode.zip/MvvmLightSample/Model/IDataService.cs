﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvvmLightSample.Model
{
  public interface IDataService
  {
    void GetApplicationTitle(Action<DataItem, Exception> callback);
    void GetPageName(Action<DataItem, Exception> callback);
  }
}
