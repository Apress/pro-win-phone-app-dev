﻿using System;

namespace MvvmLightSample.Model
{
  public class DataService : IDataService
  {
    public void GetApplicationTitle(Action<DataItem, Exception> callback)
    {
      var item = new DataItem("CHAPTER SIX");
      callback(item, null);
    }

    public void GetPageName(Action<DataItem, Exception> callback)
    {
      var item = new DataItem("mvvm light sample");
      callback(item, null);
    }
  }
}