﻿using System.Runtime.Serialization;
using GalaSoft.MvvmLight;

namespace MvvmLightSample.Model
{
  [DataContract()]
  public class Vendor : ObservableObject
  {
    private string AccountNumberField;
    private byte CreditRatingField;
    private string NameField;

    [DataMemberAttribute()]
    public string AccountNumber
    {
      get
      { return this.AccountNumberField; }
      set
      { this.AccountNumberField = value;
        RaisePropertyChanged("AccountNumber");}
    }

    [DataMemberAttribute()]
    public byte CreditRating
    {
      get
      { return this.CreditRatingField; }
      set
      {this.CreditRatingField = value;
        RaisePropertyChanged("CreditRating");}
    }

    [DataMemberAttribute()]
    public string Name
    {
      get
      {return this.NameField;}
      set
      {this.NameField = value;
        RaisePropertyChanged("Name");}
    }
  }
}
