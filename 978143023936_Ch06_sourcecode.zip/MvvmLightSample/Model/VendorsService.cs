﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net;
using Newtonsoft.Json;

namespace MvvmLightSample.Model
{
  public class VendorsService : IVendorsService
  {
    private const string ServiceUri = "http://localhost:9191/AdventureWorksRestJSON.svc/Vendors";
    public void GetVendors(Action<IList<Vendor>, Exception> callback)
    {
      var client = new WebClient();
      client.DownloadStringCompleted += ClientDownloadStringCompleted;
      client.DownloadStringAsync(new Uri(ServiceUri), callback);
    }

    private static void ClientDownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
      var callback = e.UserState as Action<IList<Vendor>, Exception>;

      if (callback == null)
      {
        return;
      }

      if (e.Error != null)
      {
        callback(null, e.Error);
        return;
      }

      ObservableCollection<Vendor> vendors;
      vendors = JsonConvert.DeserializeObject<ObservableCollection<Vendor>>(e.Result);
      callback(vendors, null);
    }
  }
}