﻿using Microsoft.Phone.Controls;

namespace MvvmLightSample
{
  public partial class VendorsView : PhoneApplicationPage
  {
    // Constructor
    public VendorsView()
    {
      InitializeComponent();
    }
  }
}
