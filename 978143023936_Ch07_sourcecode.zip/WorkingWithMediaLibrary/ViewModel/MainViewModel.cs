﻿using GalaSoft.MvvmLight;
using WorkingWithMediaLibrary.Model;
using Microsoft.Xna.Framework.Media;
using System.Collections.Generic;

namespace WorkingWithMediaLibrary.ViewModel
{
  public class MainViewModel : ViewModelBase
  {
    private readonly IMediaLibraryAlbumsService _mediaLibraryAlbumsService;
    private readonly IMediaLibraryArtistsService _mediaLibraryArtistsService;
    private readonly IMediaLibraryPlayListsService _mediaLibraryPlaylistsService;
    private readonly IMediaLibrarySongsService _mediaLibrarySongsService;

    public string ApplicationTitle
    {
      get
      {
        return "my media";
      }
    }

    public MainViewModel(IMediaLibraryAlbumsService mediaLibraryAlbumsService,
      IMediaLibraryArtistsService mediaLibraryArtistsService,
      IMediaLibraryPlayListsService mediaLibraryPlaylistsService,
      IMediaLibrarySongsService mediaLibrarySongsService)
    {
      _mediaLibraryAlbumsService = mediaLibraryAlbumsService;
      _mediaLibraryArtistsService = mediaLibraryArtistsService;
      _mediaLibraryPlaylistsService = mediaLibraryPlaylistsService;
      _mediaLibrarySongsService = mediaLibrarySongsService;
      //Albums
      _mediaLibraryAlbumsService.GetData(
          (albums, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            Albums = (List<Album>)albums;
          });
      //Artists
      _mediaLibraryArtistsService.GetData(
    (artists, error) =>
    {
      if (error != null)
      {
        // Report error here
        return;
      }
      Artists = (List<Artist>)artists;
    });
      //Playlists
      _mediaLibraryPlaylistsService.GetData(
      (playlists, error) =>
      {
        if (error != null)
        {
          // Report error here
          return;
        }
        Playlists = (List<Playlist>)playlists;
      });
      //Songs
      _mediaLibrarySongsService.GetData(
      (songs, error) =>
      {
        if (error != null)
        {
          // Report error here
          return;
        }
        Songs = (List<Song>)songs;
      });
    }

    #region Albums
    public const string AlbumsPropertyName = "Albums";
    private List<Album> _randomAlbums = null;
    public List<Album> Albums
    {
      get
      {
        return _randomAlbums;
      }

      set
      {
        if (_randomAlbums == value)
        {
          return;
        }

        var oldValue = _randomAlbums;
        _randomAlbums = value;

        // Update bindings, no broadcast
        RaisePropertyChanged(AlbumsPropertyName);
      }
    }
    #endregion

    #region Artist
    public const string ArtistsPropertyName = "Artists";
    private List<Artist> _artists = null;
    public List<Artist> Artists
    {
      get
      {
        return _artists;
      }

      set
      {
        if (_artists == value)
        {
          return;
        }

        var oldValue = _artists;
        _artists = value;
        RaisePropertyChanged(ArtistsPropertyName);
      }
    }
    #endregion

    #region Songs
    public const string SongsPropertyName = "Songs";
    private List<Song> _songs = null;
    public List<Song> Songs
    {
      get
      {
        return _songs;
      }

      set
      {
        if (_songs == value)
        {
          return;
        }

        var oldValue = _songs;
        _songs = value;
        RaisePropertyChanged(SongsPropertyName);
      }
    }
    #endregion

    #region Playlist
    public const string PlaylistsPropertyName = "Playlists";
    private List<Playlist> _playlist = null;
    public List<Playlist> Playlists
    {
      get
      {
        return _playlist;
      }

      set
      {
        if (_playlist == value)
        {
          return;
        }

        var oldValue = _playlist;
        _playlist = value;
        RaisePropertyChanged(PlaylistsPropertyName);
      }
    }
    #endregion

    ////public override void Cleanup()
    ////{
    ////    // Clean up if needed

    ////    base.Cleanup();
    ////}
  }
}