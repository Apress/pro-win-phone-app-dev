﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Ioc;
using Microsoft.Practices.ServiceLocation;
using WorkingWithMediaLibrary.Model;

namespace WorkingWithMediaLibrary.ViewModel
{
  
  public class ViewModelLocator
  {
    static ViewModelLocator()
    {
      ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

      if (ViewModelBase.IsInDesignModeStatic)
      {
        SimpleIoc.Default.Register<IMediaLibraryAlbumsService, Design.DesignMediaLibraryAlbumsService>();
        SimpleIoc.Default.Register<IMediaLibraryArtistsService, Design.DesignMediaLibraryArtistsService>();
        SimpleIoc.Default.Register<IMediaLibraryPlayListsService, Design.DesignMediaLibraryPlayListsService>();
        SimpleIoc.Default.Register<IMediaLibrarySongsService, Design.DesignMediaLibrarySongsService>();
      }
      else
      {
        SimpleIoc.Default.Register<IMediaLibraryAlbumsService, MediaLibraryAlbumsService>();
        SimpleIoc.Default.Register<IMediaLibraryArtistsService, MediaLibraryArtistsService>();
        SimpleIoc.Default.Register<IMediaLibraryPlayListsService, MediaLibraryPlayListsService>();
        SimpleIoc.Default.Register<IMediaLibrarySongsService, MediaLibrarySongsService>();
      }

      SimpleIoc.Default.Register<MainViewModel>();
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance",
        "CA1822:MarkMembersAsStatic",
        Justification = "This non-static member is needed for data binding purposes.")]
    public MainViewModel Main
    {
      get
      {
        return ServiceLocator.Current.GetInstance<MainViewModel>();
      }
    }

    /// <summary>
    /// Cleans up all the resources.
    /// </summary>
    public static void Cleanup()
    {
    }
  }
}