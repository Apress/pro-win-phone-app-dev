﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;
using WorkingWithMediaLibrary.Model;

namespace WorkingWithMediaLibrary.Design
{
  public class DesignMediaLibrarySongsService : IMediaLibrarySongsService
  {
    public void GetData(Action<List<Song>, Exception> callback)
    {
      List<Song> songs = new List<Song>()
      {
        //Cannot create Song items - no constructor
      };
      callback(songs, null);
    }
  }
}
