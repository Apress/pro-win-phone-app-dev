﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;
using WorkingWithMediaLibrary.Model;

namespace WorkingWithMediaLibrary.Design
{
  public class DesignMediaLibraryPlayListsService : IMediaLibraryPlayListsService
  {
    public void GetData(Action<List<Playlist>, Exception> callback)
    {
      List<Playlist> playlists = new List<Playlist>()
      {
        //Cannot create Playlist items - no constructor
      };
      callback(playlists, null);
    }
  }
}
