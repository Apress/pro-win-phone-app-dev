﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;
using WorkingWithMediaLibrary.Model;

namespace WorkingWithMediaLibrary.Design
{
  public class DesignMediaLibraryArtistsService : IMediaLibraryArtistsService
  {
    public void GetData(Action<List<Artist>, Exception> callback)
    {
      List<Artist> artists = new List<Artist>()
      {
        //Cannot create Artist items - no constructor
      };
      callback(artists, null);
    }
  }
}
