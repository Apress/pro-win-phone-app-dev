﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;
using WorkingWithMediaLibrary.Model;

namespace WorkingWithMediaLibrary.Design
{
  public class DesignMediaLibraryAlbumsService : IMediaLibraryAlbumsService
  {
    public void GetData(Action<List<Album>, Exception> callback)
    {
      List<Album> albums = new List<Album>()
      {
        //Cannot create Album items - no constructor
      };
      callback(albums, null);
    }
  }
}
