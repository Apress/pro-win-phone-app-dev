﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Media;

namespace WorkingWithMediaLibrary.Model
{
  public class MediaLibraryArtistsService : IMediaLibraryArtistsService
  {
    private MediaLibrary _mediaLibrary;
    public void GetData(Action<List<Artist>, Exception> callback)
    {
      _mediaLibrary = new MediaLibrary();
      List<Artist> artists = new List<Artist>();
      Artist artist = null;
      for (int i = 0; i < _mediaLibrary.Artists.Count; i++)
      {
        artist = _mediaLibrary.Artists[i];
        artists.Add(artist);
      }

      callback(artists, null);
      _mediaLibrary.Dispose();
    }
  }
}
