﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Media;

namespace WorkingWithMediaLibrary.Model
{
  public class MediaLibrarySongsService : IMediaLibrarySongsService
  {
      private MediaLibrary _mediaLibrary;

    public void GetData(Action<List<Song>, Exception> callback)
    {
      _mediaLibrary = new MediaLibrary();
      List<Song> songs = new List<Song>();
      Song song = null;
      for (int i = 0; i < _mediaLibrary.Songs.Count; i++)
      {
        song = _mediaLibrary.Songs[i];
        songs.Add(song);
      }

      callback(songs, null);
      _mediaLibrary.Dispose();
    }
  }
}
