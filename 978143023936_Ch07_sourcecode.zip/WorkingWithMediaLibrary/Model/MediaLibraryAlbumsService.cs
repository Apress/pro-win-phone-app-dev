﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Media;

namespace WorkingWithMediaLibrary.Model
{
  public class MediaLibraryAlbumsService : IMediaLibraryAlbumsService
  {
    private MediaLibrary _mediaLibrary;
    public void GetData(Action<List<Album>, Exception> callback)
    {
      _mediaLibrary = new MediaLibrary();
      List<Album> slbums = new List<Album>();
      Album album = null;
      for (int i = 0; i < _mediaLibrary.Albums.Count; i++)
      {
        album = _mediaLibrary.Albums[i];
        slbums.Add(album);
      }

      callback(slbums, null);
      _mediaLibrary.Dispose();
    }
  }
}
