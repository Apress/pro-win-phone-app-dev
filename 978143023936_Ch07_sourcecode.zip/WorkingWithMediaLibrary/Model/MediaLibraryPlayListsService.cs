﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Media;

namespace WorkingWithMediaLibrary.Model
{
  public class MediaLibraryPlayListsService : IMediaLibraryPlayListsService
  {
    private MediaLibrary _mediaLibrary;

    public void GetData(Action<List<Playlist>, Exception> callback)
    {
      _mediaLibrary = new MediaLibrary();
      List<Playlist> playlists = new List<Playlist>();
      Playlist playlist = null;
      for (int i = 0; i < _mediaLibrary.Playlists.Count; i++)
      {
        playlist = _mediaLibrary.Playlists[i];
        playlists.Add(playlist);
      }

      callback(playlists, null);
      _mediaLibrary.Dispose();
    }
  }
}
