﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;

namespace WorkingWithMediaLibrary.Model
{
  public interface IMediaLibrarySongsService
  {
     void GetData(Action<List<Song>, Exception> callback);
  }
}
