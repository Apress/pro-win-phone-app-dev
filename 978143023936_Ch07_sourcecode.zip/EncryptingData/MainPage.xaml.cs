﻿using System.Windows;
using System.Windows.Controls;
using EncryptingData.ViewModel;
using Microsoft.Phone.Controls;
using System.Windows.Data;
using System.Reflection;

namespace EncryptingData
{
  public partial class MainPage : PhoneApplicationPage
  {
    MainViewModel vm;
    // Constructor
    public MainPage()
    {
      InitializeComponent();
      vm = this.DataContext as MainViewModel;
    }

    private void EncryptAppBarBtn_Click(object sender, System.EventArgs e)
    {
      if ((passwordPasswordBox.Password != string.Empty) &&
        (saltPasswordBox.Password != string.Empty))
        vm.EncryptData();
      else
        MessageBox.Show("Please enter the Password and Salt to encrypt.");
    }

    private void DecryptAppBarBtn_Click(object sender, System.EventArgs e)
    {    
      if ((passwordPasswordBox.Password != string.Empty) &&
        (saltPasswordBox.Password != string.Empty))
        vm.DecryptData();
      else
        MessageBox.Show("Please enter the Password and Salt to decrypt.");
    }

    private void SaveIsoAppBarBtn_Click(object sender, System.EventArgs e)
    {
      vm.SaveEncryptedDataToIsolatedStorage();
    }

    private void LoadIsoAppBarBtn_Click(object sender, System.EventArgs e)
    {
      vm.LoadEncryptedDataFromIsolatedStorage();
    }

    private void PasswordBox_LostFocus(object sender, 
      System.Windows.RoutedEventArgs e)
    {
      if (((PasswordBox)sender).Password.Length < 8)
        MessageBox.Show("Salt Value must be at least eight characters.",
          "Minimum Length Error",MessageBoxButton.OK);
    }
  }
}
