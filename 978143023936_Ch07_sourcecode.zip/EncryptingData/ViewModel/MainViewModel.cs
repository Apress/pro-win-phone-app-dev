﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using GalaSoft.MvvmLight;
using System.Windows.Input;

namespace EncryptingData.ViewModel
{
  public class MainViewModel : ViewModelBase
  {
    //Get the settings store
    //Store encrypted Password and Salt values in settings
    IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;

    public MainViewModel()
    {
      if (!ViewModelBase.IsInDesignModeStatic)
      {
        if (settings.Contains("Password"))
        {
          byte[] encryptedPasswordBytes = (byte[])settings["Password"];
          byte[] decryptedPasswordBytes = ProtectedData.Unprotect(encryptedPasswordBytes, null);
          Password = Encoding.UTF8.GetString(decryptedPasswordBytes, 0, decryptedPasswordBytes.Length);

        }
        if (settings.Contains("Salt"))
        {
          byte[] encryptedSaltBytes = (byte[])settings["Salt"];
          byte[] decryptedSaltBytes = ProtectedData.Unprotect(encryptedSaltBytes, null);
          Salt = Encoding.UTF8.GetString(decryptedSaltBytes, 0, decryptedSaltBytes.Length);
        }
        if (Password != String.Empty)
          SavePasswordAndSalt = true;
      }
    }

    public string ApplicationTitle
    {
      get
      {
        return "CHAPTER SEVEN";
      }
    }

    public string PageName
    {
      get
      {
        return "encrypting data";
      }
    }


    #region Persist Password and Salt Properties and Methods
    public const string SavePasswordAndSaltPropertyName = "SavePasswordAndSalt";
    private bool _savePasswordAndSalt = false;
    public bool SavePasswordAndSalt
    {
      get
      {
        return _savePasswordAndSalt;
      }

      set
      {
        if (_savePasswordAndSalt == value)
        {
          return;
        }
        //Do not check the box unless
        //Password and Salt values are configured
        if ((Password == String.Empty) ||
           (Salt == String.Empty))
        {
          _savePasswordAndSalt = false;
          RaisePropertyChanged(SavePasswordAndSaltPropertyName);
          return;
        }
        _savePasswordAndSalt = value;
        RaisePropertyChanged(SavePasswordAndSaltPropertyName);
        ProcessSaltAndPasswordValues();
      }
    }

    private void ProcessSaltAndPasswordValues()
    {
      if (SavePasswordAndSalt)
      {
        if (settings.Contains("Password"))
          settings.Remove("Password");
        if (settings.Contains("Salt"))
          settings.Remove("Salt");
        //Set Entropy to null in the Protect method for this demo.  
        //You could instead collect a user PIN and use that value
        //for entropy to provide stronger security.
        settings.Add("Password", ProtectedData.Protect(Encoding.UTF8.GetBytes(Password), null));
        settings.Add("Salt", ProtectedData.Protect(Encoding.UTF8.GetBytes(Salt), null));
      }
      else
      {
        if (settings.Contains("Password"))
          settings.Remove("Password");
        if (settings.Contains("Salt"))
          settings.Remove("Salt");
      }
    }
    #endregion

    #region Encrypt/Decrypt Properties
    public const string DataToEncryptPropertyName = "DataToEncrypt";
    private string _dataToEncrypt = null;
    public string DataToEncrypt
    {
      get
      {
        return _dataToEncrypt;
      }

      set
      {
        if (_dataToEncrypt == value)
        {
          return;
        }

        var oldValue = _dataToEncrypt;
        _dataToEncrypt = value;
        RaisePropertyChanged(DataToEncryptPropertyName);
      }
    }


    public const string StorageKeyNamePropertyName = "StorageKeyName";
    private string _storageKeyName = "Passwordkey";
    public string StorageKeyName
    {
      get
      {
        return _storageKeyName;
      }

      set
      {
        if (_storageKeyName == value)
        {
          return;
        }
        var oldValue = _storageKeyName;
        _storageKeyName = value;
        RaisePropertyChanged(StorageKeyNamePropertyName);
      }
    }

    public const string PasswordPropertyName = "Password";
    private string _password = "";
    public string Password
    {
      get
      {
        return _password;
      }

      set
      {
        if (_password == value)
        {
          return;
        }

        var oldValue = _password;
        _password = value;
        RaisePropertyChanged(PasswordPropertyName);
      }
    }

    public const string SaltPropertyName = "Salt";
    private string _salt = "";
    public string Salt
    {
      get
      {
        return _salt;
      }

      set
      {
        if (_salt == value)
        {
          return;
        }

        var oldValue = _salt;
        _salt = value;
        RaisePropertyChanged(SaltPropertyName);
      }
    }

    public const string EncryptedDataPropertyName = "EncryptedData";
    private string _encryptedData = null;
    public string EncryptedData
    {
      get
      {
        return _encryptedData;
      }

      set
      {
        if (_encryptedData == value)
        {
          return;
        }

        var oldValue = _encryptedData;
        _encryptedData = value;
        RaisePropertyChanged(EncryptedDataPropertyName);
      }
    }

    public const string DecryptedDataPropertyName = "DecryptedData";
    private string _decryptedData = null;
    public string DecryptedData
    {
      get
      {
        return _decryptedData;
      }

      set
      {
        if (_decryptedData == value)
        {
          return;
        }

        var oldValue = _decryptedData;
        _decryptedData = value;
        RaisePropertyChanged(DecryptedDataPropertyName);
      }
    }
    #endregion

    #region Encrypt/Decrypt Methods
    public void EncryptData()
    {
      if ((Password != String.Empty) &&
          (Salt != String.Empty))
        using (AesManaged aes = new AesManaged())
        {
          Rfc2898DeriveBytes rfc2898 = new Rfc2898DeriveBytes(Password,
            Encoding.UTF8.GetBytes(Salt), 10000);
          aes.Key = rfc2898.GetBytes(32);
          aes.IV = rfc2898.GetBytes(16);
          using (MemoryStream memoryStream = new MemoryStream())
          {
            using (CryptoStream cryptoStream = new CryptoStream(memoryStream,
              aes.CreateEncryptor(), CryptoStreamMode.Write))
            {
              //Encrypt Data with created CryptoStream
              byte[] secret = Encoding.UTF8.GetBytes(DataToEncrypt);
              cryptoStream.Write(secret, 0, secret.Length);
              cryptoStream.FlushFinalBlock();
              aes.Clear();
              //Set values on UI thread 
              Deployment.Current.Dispatcher.BeginInvoke(() =>
              {
                EncryptedData = Convert.ToBase64String(memoryStream.ToArray());
              });
            }
          }
        }
    }

    public void DecryptData()
    {
      MemoryStream memoryStream = null;

      using (AesManaged aes = new AesManaged())
      {
        //Generate Key and IV values for decryption
        Rfc2898DeriveBytes rfc2898 = new Rfc2898DeriveBytes(Password, Encoding.UTF8.GetBytes(Salt), 10000);
        aes.Key = rfc2898.GetBytes(32);
        aes.IV = rfc2898.GetBytes(16);

        using (memoryStream = new MemoryStream())
        {
          using (CryptoStream cryptoStream =
            new CryptoStream(memoryStream, aes.CreateDecryptor(),
                             CryptoStreamMode.Write))
          {
            //Decrypt Data
            byte[] secret = Convert.FromBase64String(EncryptedData);
            cryptoStream.Write(secret, 0, secret.Length);
            cryptoStream.FlushFinalBlock();
            byte[] decryptBytes = memoryStream.ToArray();
            aes.Clear();
            //Update values on UI thread
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
              DecryptedData = Encoding.UTF8.GetString(decryptBytes, 0, decryptBytes.Length);
              DataToEncrypt = Encoding.UTF8.GetString(decryptBytes, 0, decryptBytes.Length);
            });
          }
        }
      }
    }
    #endregion

    #region Save/Load Encrypted Data from Iso Storage
    public void SaveEncryptedDataToIsolatedStorage()
    {
      //Save secret to Application Settings
      if (EncryptedData != "")
      {
        if (IsolatedStorageSettings.ApplicationSettings.Contains(StorageKeyName))
        {
          IsolatedStorageSettings.ApplicationSettings[StorageKeyName] =
            EncryptedData;
        }
        else
        {
          IsolatedStorageSettings.ApplicationSettings.Add(
            StorageKeyName, EncryptedData);
        }
      }
    }

    public void LoadEncryptedDataFromIsolatedStorage()
    {
      //Retrieve secret from Application Settings
      if (IsolatedStorageSettings.ApplicationSettings.Contains(StorageKeyName))
      {
        Deployment.Current.Dispatcher.BeginInvoke(() =>
        {
          EncryptedData =
            IsolatedStorageSettings.ApplicationSettings[StorageKeyName].ToString();
        });
      }
      else
      {
        Deployment.Current.Dispatcher.BeginInvoke(() =>
        {
          EncryptedData = "";
        });
      }
    }
    #endregion
  }
}