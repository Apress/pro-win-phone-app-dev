﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using AppConnectBingSearch.Model;
using System.Windows;

namespace AppConnectBingSearch.ViewModel
{
  public class AppConnectSearchViewModel : INotifyPropertyChanged
  {
    public AppConnectSearchViewModel()
    {
      AppConnectUriParameters = 
        new ObservableCollection<AppConnectSearchUriParams>();
    }

    private ObservableCollection<AppConnectSearchUriParams> 
      _AppConnectUriParameters;
    public ObservableCollection<AppConnectSearchUriParams> 
      AppConnectUriParameters
    {
      get { return _AppConnectUriParameters; }
      set
      {
        if (_AppConnectUriParameters != value)
        {
          _AppConnectUriParameters = value;
          NotifyPropertyChanged("AppConnectUriParameters");
        }
      }
    }
    
    public void LoadUriParams(IDictionary<string, string> QueryString)
    {
      AppConnectUriParameters.Clear();

       foreach (string KeyName in QueryString.Keys)
      {
        // Default value for parameter 
        string KeyValue = "<no value present in deep link>";
        QueryString.TryGetValue(KeyName, out KeyValue);
        AppConnectUriParameters.Add(
          new AppConnectSearchUriParams(KeyName, KeyValue));
      }
    }

    #region INotifyPropertyChanged Members
    public event PropertyChangedEventHandler PropertyChanged;

    private void NotifyPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }
    #endregion
  }
}
