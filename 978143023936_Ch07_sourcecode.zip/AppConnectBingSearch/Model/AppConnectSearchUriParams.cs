﻿using System.ComponentModel;

namespace AppConnectBingSearch.Model
{
  public class AppConnectSearchUriParams
  {
    public AppConnectSearchUriParams(string Name, string Value)
    {
      _paramName = Name.Trim();

      if (_paramName == "Category")
      {
        _paramValue = Value.Replace(",", ",\n");
      }
      else
      {
        _paramValue = Value;
      }
    }

      private string _paramName;
      public string ParamName
      {
        get { return _paramName; }
        set
        {
          if (_paramName != value)
          {
            _paramName = value;
            NotifyPropertyChanged("ParamName");
          }
        }
      }

      private string _paramValue;
      public string ParamValue
      {
        get { return _paramValue; }
        set
        {
          if (_paramValue != value)
          {
            _paramValue = value;
            NotifyPropertyChanged("ParamValue");
          }
        }
      }

      #region INotifyPropertyChanged Members
      public event PropertyChangedEventHandler PropertyChanged;

      private void NotifyPropertyChanged(string propertyName)
      {
        if (PropertyChanged != null)
        {
          PropertyChanged(this, 
            new PropertyChangedEventArgs(propertyName));
        }
      }
      #endregion
    }
  }
