﻿using System;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;

namespace AdvancedMVVM.Model
{
  public class PageItem : ViewModelBase
  {
    public PageItem()
    {
      NavigateToPageCommand = new RelayCommand<Uri>(
       param => SendNavigationRequestMessage(param));
    }

    #region PageItem properties
    public const string PageTitlePropertyName = "PageTitle";
    private string _pageTitle = null;
    public string PageTitle
    {
      get
      {
        return _pageTitle;
      }
      set
      {
        if (_pageTitle == value)
        {
          return;
        }

        var oldValue = _pageTitle;
        _pageTitle = value;
        RaisePropertyChanged(PageTitlePropertyName);
      }
    }


    public const string PageUriPropertyName = "PageUri";
    private Uri _pageUri = null;
    public Uri PageUri
    {
      get
      {
        return _pageUri;
      }
      set
      {
        if (_pageUri == value)
        {
          return;
        }

        var oldValue = _pageUri;
        _pageUri = value;

        // Update bindings, no broadcast
        RaisePropertyChanged(PageUriPropertyName);
      }
    }
    #endregion

    #region Commanding and Messaging
    public RelayCommand<Uri> NavigateToPageCommand
    {
      get;
      private set;
    }

    protected void SendNavigationRequestMessage(Uri uri)
    {
      Messenger.Default.Send<Uri>(uri, "PageNavRequest");
    }
    #endregion
  }
}
