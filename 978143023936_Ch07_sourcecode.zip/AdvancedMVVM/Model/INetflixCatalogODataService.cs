﻿using System;
using System.Data.Services.Client;
using AdvancedMVVM.NetflixAPI;

namespace AdvancedMVVM.Model
{
  public interface INetflixCatalogODataService
  {
    void GetNetflixCatalogFeedItems(Action<DataServiceCollection<Title>, Exception> callback);
  }
}
