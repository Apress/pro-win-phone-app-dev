﻿using System;
using System.Collections.Generic;

namespace AdvancedMVVM.Model
{
  public interface IPageItemsDataService
  {
    void GetPageItems(Action<IList<PageItem>, Exception> callback);
  }
}