﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using System.Data.Services.Client;
using AdvancedMVVM.NetflixAPI;

namespace AdvancedMVVM.Model
{
  public class NetflixCatalogODataService : INetflixCatalogODataService
  {
    private NetflixCatalog ODataContext;
    private Action<DataServiceCollection<Title>, Exception> _callback;
    private DataServiceCollection<Title> _topMovieTitles;

    private const string ServiceUri = "http://odata.netflix.com/Catalog/";
    public void GetNetflixCatalogFeedItems(Action<DataServiceCollection<Title>, Exception> callback)
    {
      ODataContext = new NetflixCatalog(
        new Uri(ServiceUri,
             UriKind.Absolute));
      //Save a reference to the callback in this case
      //Cannot pass it via the LoadAsync method for OData
      _callback = callback;
      _topMovieTitles = new DataServiceCollection<Title>(ODataContext);
      _topMovieTitles.LoadCompleted +=
        new EventHandler<LoadCompletedEventArgs>(topMovieTitles_LoadCompleted);
      _topMovieTitles.LoadAsync(new Uri("/Titles()", UriKind.Relative));
    }
    private void topMovieTitles_LoadCompleted(object sender, LoadCompletedEventArgs e)
    {
      if (_topMovieTitles == null)
      {
        return;
      }

      if (e.Error != null)
      {
        _callback(_topMovieTitles, e.Error);
        return;
      }
      _callback(_topMovieTitles, null);
    }
  }
}
