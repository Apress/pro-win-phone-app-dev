﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Xml.Linq;

namespace AdvancedMVVM.Model
{
  public class FeedItemsDataService : IFeedItemsDataService
  {
    private const string ServiceUri =
      "http://public.create.msdn.com/Feeds/CcoFeeds.svc/CmsFeed?group=Education Catalog List";
    public void GetFeedItems(Action<IList<FeedItem>, Exception> callback)
    {
      var client = new WebClient();
      client.DownloadStringCompleted += ClientDownloadStringCompleted;
      client.DownloadStringAsync(new Uri(ServiceUri), callback);
    }
    private static void ClientDownloadStringCompleted(object sender,
      DownloadStringCompletedEventArgs e)
    {
      var callback = e.UserState as Action<IList<FeedItem>, Exception>;

      XDocument doc = XDocument.Parse(e.Result);
      List<FeedItem> feedItems = (from results in doc.Descendants("item")
                                  select new FeedItem
                                  {
                                    Title = results.Element("title").Value.ToString(),
                                    Link = new Uri(results.Element("link").Value.ToString(),
                                      UriKind.Absolute),
                                    Description =
                                       results.Element("description").Value.ToString()
                                  }).ToList<FeedItem>();

      if (callback == null)
      {
        return;
      }

      if (e.Error != null)
      {
        callback(null, e.Error);
        return;
      }
      callback(feedItems, null);
    }
  }
}
