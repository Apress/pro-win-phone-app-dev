﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using AdvancedMVVM.Model;
using System.Collections.Generic;

namespace AdvancedMVVM.Design
{
  public class DesignFeedITemDataService : IFeedItemsDataService
  {
    public void GetFeedItems(Action<IList<FeedItem>, Exception> callback)
    {
      List<FeedItem> FeedItems = new List<FeedItem>(){
        new FeedItem(){Title="Feed Item 1", Description="Feed Item 1 description goes here.  It is a long string of HTML.", Link=new Uri("http://create.msdn.com", UriKind.Absolute)},
        new FeedItem(){Title="Feed Item 2", Description="Feed Item 2 description goes here.  It is a long string of HTML.", Link=new Uri("http://create.msdn.com", UriKind.Absolute)},
        new FeedItem(){Title="Feed Item 3", Description="Feed Item 3 description goes here.  It is a long string of HTML.", Link=new Uri("http://create.msdn.com", UriKind.Absolute)},
        new FeedItem(){Title="Feed Item 4", Description="Feed Item 4 description goes here.  It is a long string of HTML.", Link=new Uri("http://create.msdn.com", UriKind.Absolute)},
        new FeedItem(){Title="Feed Item 5", Description="Feed Item 5 description goes here.  It is a long string of HTML.", Link=new Uri("http://create.msdn.com", UriKind.Absolute)},
        new FeedItem(){Title="Feed Item 6", Description="Feed Item 6 description goes here.  It is a long string of HTML.", Link=new Uri("http://create.msdn.com", UriKind.Absolute)}
      };
      callback(FeedItems, null);
    }
  }
}
