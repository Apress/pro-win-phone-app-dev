﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using AdvancedMVVM.Model;
using System.Collections.Generic;

namespace AdvancedMVVM.Design
{
  public class DesignPageItemsDataService : IPageItemsDataService
  {
    public void GetPageItems(Action<IList<PageItem>, Exception> callback)
    {
      List<PageItem> PageItems = new List<PageItem>()
      {
        new PageItem(){PageTitle="syndicated services",
          PageUri=new Uri("/View/SyndicatedServices.xaml",UriKind.Relative)},
        new PageItem(){PageTitle="showing progress",
          PageUri=new Uri("/View/ShowingProgress.xaml",UriKind.Relative)},
        new PageItem(){PageTitle="lazy load images",
          PageUri=new Uri("/View/LazyLoadImages.xaml",UriKind.Relative)},
        new PageItem(){PageTitle="data binding to anything",
          PageUri=new Uri("/View/DatabindToAnything.xaml",UriKind.Relative)}
      };
      callback(PageItems, null);
    }
  }
}
