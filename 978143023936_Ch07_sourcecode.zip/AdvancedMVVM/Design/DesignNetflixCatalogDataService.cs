﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using AdvancedMVVM.Model;
using System.Collections.Generic;
using System.Data.Services.Client;
using AdvancedMVVM.NetflixAPI;

namespace AdvancedMVVM.Design
{
  public class DesignNetflixCatalogDataService : INetflixCatalogODataService
  {
    public void GetNetflixCatalogFeedItems(Action<DataServiceCollection<Title>, Exception> callback)
    {
      DataServiceCollection<Title> CatalogItems = new DataServiceCollection<Title>()
      {
       new Title(){Id="1", Name="Movie 1", BoxArt = new BoxArt(){SmallUrl="/Design/FakeData/FakeBoxArt.jpg"}},
       new Title(){Id="2", Name="Movie 2", BoxArt = new BoxArt(){SmallUrl="/Design/FakeData/FakeBoxArt.jpg"}},
       new Title(){Id="3", Name="Movie 3", BoxArt = new BoxArt(){SmallUrl="/Design/FakeData/FakeBoxArt.jpg"}}
      };
      callback(CatalogItems, null);
    }
  }
}
