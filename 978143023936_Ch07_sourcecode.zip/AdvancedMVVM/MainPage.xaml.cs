﻿using Microsoft.Phone.Controls;
using GalaSoft.MvvmLight.Messaging;
using System;

namespace AdvancedMVVM
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();

      Messenger.Default.Register<Uri>(
       this, "PageNavRequest",
       (uri) => NavigationService.Navigate(uri));
    }
  }
}
