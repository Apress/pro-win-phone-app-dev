﻿using GalaSoft.MvvmLight;
using AdvancedMVVM.Model;
using System.Collections.Generic;

namespace AdvancedMVVM.ViewModel
{
  public class MainViewModel : ViewModelBase
  {
    private readonly IPageItemsDataService _pageItemsService;

    public string ApplicationTitle
    {
      get { return "CHAPTER SEVEN"; }
    }

    public string PageName
    {
      get { return "advanced MVVM"; }
    }

    public MainViewModel(IPageItemsDataService dataService)
    {
      _pageItemsService = dataService;
      PageItems = new List<PageItem>();

      _pageItemsService.GetPageItems(
          (pageItems, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            PageItems = (List<PageItem>)pageItems;
          });
    }

    public const string PagItemsPropertyName = "PageItems";
    private List<PageItem> _pages = null;
    public List<PageItem> PageItems
    {
      get
      {
        return _pages;
      }

      protected set
      {
        if (_pages == value)
        {
          return;
        }

        var oldValue = _pages;
        _pages = value;

        // Update bindings, no broadcast
        RaisePropertyChanged(PagItemsPropertyName);
      }
    }
  }
}