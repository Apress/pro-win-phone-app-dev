﻿using GalaSoft.MvvmLight;
using AdvancedMVVM.Model;
using System.Collections.Generic;
using System.Windows;
using System.Data.Services.Client;
using AdvancedMVVM.NetflixAPI;

namespace AdvancedMVVM.ViewModel
{
  public class LazyLoadViewModel : ViewModelBase
  {
    private readonly INetflixCatalogODataService _netflixCatalogfeedItemsService;
    public LazyLoadViewModel(INetflixCatalogODataService dataService)
    {
      _netflixCatalogfeedItemsService = dataService;
    }

    public void DownloadNetflixCatalog()
    {
      ShowProgressBar = true;
      System.Threading.Thread.Sleep(3000);

      _netflixCatalogfeedItemsService.GetNetflixCatalogFeedItems(
          (topMovieTitles, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            TopMovieTitles = (DataServiceCollection<Title>)topMovieTitles;
            ShowProgressBar = false;
          });
    }

    private string TopMovieTitlesPropertyName = "TopMovieTitles";
    private DataServiceCollection<Title> topMovieTitles;
    public DataServiceCollection<Title> TopMovieTitles
    {
      get { return topMovieTitles; }
      private set
      {
        if (null == value)
          return;
        topMovieTitles = value;
        RaisePropertyChanged(TopMovieTitlesPropertyName);
      }
    }


    public const string ShowProgressBarPropertyName = "ShowProgressBar";
    private bool _showProgressBar = false;
    public bool ShowProgressBar
    {
      get
      {
        return _showProgressBar;
      }
      
      set
      {
        if (_showProgressBar == value)
        {
          return;
        }
        var oldValue = _showProgressBar;
        _showProgressBar = value;
        RaisePropertyChanged(ShowProgressBarPropertyName);
      }
    }

    public string ApplicationTitle
    {
      get { return "CHAPTER SEVEN - ADVANCED MVVM"; }
    }

    public string PageName
    {
      get { return "lazy load images"; }
    }
  }
}