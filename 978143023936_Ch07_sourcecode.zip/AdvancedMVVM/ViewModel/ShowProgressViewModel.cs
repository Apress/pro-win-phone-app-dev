﻿using GalaSoft.MvvmLight;
using AdvancedMVVM.Model;
using System.Collections.Generic;
using System.Windows;

namespace AdvancedMVVM.ViewModel
{
  public class ShowProgressViewModel : ViewModelBase
  {
    private readonly IFeedItemsDataService _feedItemsService;
    public ShowProgressViewModel(IFeedItemsDataService dataService)
    {
      _feedItemsService = dataService;
      FeedItems = new List<FeedItem>();
      ShowProgressBar = false;
    }

    public void DownloadAppHubFeed()
    {
      ShowProgressBar = true;
      System.Threading.Thread.Sleep(3000);

      _feedItemsService.GetFeedItems(
          (feedItems, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            FeedItems = (List<FeedItem>)feedItems;
            ShowProgressBar = false;
          });
    }

    public const string FeedItemsPropertyName = "FeedItems";
    private List<FeedItem> _feedItems = null;
    public List<FeedItem> FeedItems
    {
      get
      {
        return _feedItems;
      }

      set
      {
        if (_feedItems == value)
        {
          return;
        }

        _feedItems = value;
        RaisePropertyChanged(FeedItemsPropertyName);
      }
    }


    public const string ShowProgressPropertyName = "ShowProgressBar";
    private bool _showProgress = false;
    public bool ShowProgressBar
    {
      get
      {
        return _showProgress;
      }
      set
      {
        if (_showProgress == value)
        {
          return;
        }
        _showProgress = value;
        RaisePropertyChanged(ShowProgressPropertyName);
      }
    }

    public string ApplicationTitle
    {
      get { return "CHAPTER SEVEN - ADVANCED MVVM"; }
    }

    public string PageName
    {
      get { return "show progress"; }
    }
  }
}