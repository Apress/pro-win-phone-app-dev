﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Ioc;
using Microsoft.Practices.ServiceLocation;
using AdvancedMVVM.Model;

namespace AdvancedMVVM.ViewModel
{
  public class ViewModelLocator
  {
    static ViewModelLocator()
    {
      ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

      if (ViewModelBase.IsInDesignModeStatic)
      {
        SimpleIoc.Default.Register<IFeedItemsDataService, Design.DesignFeedITemDataService>();
        SimpleIoc.Default.Register<IPageItemsDataService, Design.DesignPageItemsDataService>();
        SimpleIoc.Default.Register<INetflixCatalogODataService, Design.DesignNetflixCatalogDataService>();
      }
      else
      {
        SimpleIoc.Default.Register<IFeedItemsDataService, FeedItemsDataService>();
        SimpleIoc.Default.Register<IPageItemsDataService, PageItemsDataService>();
        SimpleIoc.Default.Register<INetflixCatalogODataService, NetflixCatalogODataService>();
      }

      SimpleIoc.Default.Register<MainViewModel>();
      SimpleIoc.Default.Register<SyndicatedServicesViewModel>();
      SimpleIoc.Default.Register<ShowProgressViewModel>();
      SimpleIoc.Default.Register<LazyLoadViewModel>();
    }

    /// <summary>
    /// Gets the Main property.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance",
        "CA1822:MarkMembersAsStatic",
        Justification = "This non-static member is needed for data binding purposes.")]
    public MainViewModel Main
    {
      get
      {
        return ServiceLocator.Current.GetInstance<MainViewModel>();
      }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance",
        "CA1822:MarkMembersAsStatic",
        Justification = "This non-static member is needed for data binding purposes.")]
    public SyndicatedServicesViewModel FeedItems
    {
      get
      {
        return ServiceLocator.Current.GetInstance<SyndicatedServicesViewModel>();
      }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance",
    "CA1822:MarkMembersAsStatic",
    Justification = "This non-static member is needed for data binding purposes.")]
    public ShowProgressViewModel ShowProgress
    {
      get
      {
        return ServiceLocator.Current.GetInstance<ShowProgressViewModel>();
      }
    }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance",
    "CA1822:MarkMembersAsStatic",
    Justification = "This non-static member is needed for data binding purposes.")]
    public LazyLoadViewModel LazyLoad
    {
      get
      {
        return ServiceLocator.Current.GetInstance<LazyLoadViewModel>();
      }
    }

    /// <summary>
    /// Cleans up all the resources.
    /// </summary>
    public static void Cleanup()
    {
    }
  }
}