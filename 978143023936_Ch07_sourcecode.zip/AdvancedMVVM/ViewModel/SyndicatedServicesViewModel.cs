﻿using GalaSoft.MvvmLight;
using AdvancedMVVM.Model;
using System.Collections.Generic;

namespace AdvancedMVVM.ViewModel
{
  public class SyndicatedServicesViewModel : ViewModelBase
  {
    private readonly IFeedItemsDataService _feedItemsService;
    public SyndicatedServicesViewModel(IFeedItemsDataService dataService)
    {
      _feedItemsService = dataService;
      FeedItems = new List<FeedItem>();

      _feedItemsService.GetFeedItems(
          (feedItems, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            FeedItems = (List<FeedItem>)feedItems;
          });
    }

    public const string FeedItemsPropertyName = "FeedItems";
    private List<FeedItem> _feedItems = null;
    public List<FeedItem> FeedItems
    {
      get
      {
        return _feedItems;
      }

      set
      {
        if (_feedItems == value)
        {
          return;
        }

        _feedItems = value;
        RaisePropertyChanged(FeedItemsPropertyName);
      }
    }

    public string ApplicationTitle
    {
      get { return "CHAPTER SEVEN - ADVANCED MVVM"; }
    }

    public string PageName
    {
      get { return "syndicated services"; }
    }
  }
}