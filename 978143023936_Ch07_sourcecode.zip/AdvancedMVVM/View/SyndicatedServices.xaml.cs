﻿using Microsoft.Phone.Controls;

namespace AdvancedMVVM.View
{
  /// <summary>
  /// Description for SyndicatedServices.
  /// </summary>
  public partial class SyndicatedServices : PhoneApplicationPage
  {
    /// <summary>
    /// Initializes a new instance of the SyndicatedServices class.
    /// </summary>
    public SyndicatedServices()
    {
      InitializeComponent();
    }
  }
}