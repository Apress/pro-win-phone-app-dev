﻿using Microsoft.Phone.Controls;
using AdvancedMVVM.ViewModel;

namespace AdvancedMVVM.View
{
  /// <summary>
  /// Description for DatabindToAnything.
  /// </summary>
  public partial class DatabindToAnything : PhoneApplicationPage
  {
    /// <summary>
    /// Initializes a new instance of the DatabindToAnything class.
    /// </summary>
    public DatabindToAnything()
    {
      InitializeComponent();
    }

    private void DownloadAppHubFeedAppBarBtn_Click(object sender, System.EventArgs e)
    {
      ShowProgressViewModel vm = this.DataContext as ShowProgressViewModel;
      vm.DownloadAppHubFeed();
    }
  }
}