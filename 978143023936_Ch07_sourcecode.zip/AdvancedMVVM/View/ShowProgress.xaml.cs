﻿using Microsoft.Phone.Controls;
using AdvancedMVVM.ViewModel;

namespace AdvancedMVVM.View
{
  /// <summary>
  /// Description for SyndicatedServices.
  /// </summary>
  public partial class ShowProgress : PhoneApplicationPage
  {
    /// <summary>
    /// Initializes a new instance of the SyndicatedServices class.
    /// </summary>
    public ShowProgress()
    {
      InitializeComponent();
    }

    private void DownloadAndShowProgess_Click(object sender, System.EventArgs e)
    {
      ShowProgressViewModel vm = this.DataContext as ShowProgressViewModel;
      vm.DownloadAppHubFeed();
    }
  }
}