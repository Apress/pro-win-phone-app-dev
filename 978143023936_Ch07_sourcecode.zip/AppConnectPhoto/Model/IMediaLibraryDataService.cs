﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;

namespace AppConnectPhoto.Model
{
  public interface IMediaLibraryDataService
  {
    void GetData(Action<List<Picture>, Exception> callback);
  }
}
