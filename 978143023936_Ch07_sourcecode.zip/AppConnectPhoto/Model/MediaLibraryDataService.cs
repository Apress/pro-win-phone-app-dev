﻿using System;
using Microsoft.Xna.Framework.Media;
using System.Collections.Generic;

namespace AppConnectPhoto.Model
{
  public class MediaLibraryDataService : IMediaLibraryDataService
  {
    private MediaLibrary _mediaLibrary;

    public void GetData(Action<List<Picture>, Exception> callback)
    {
      _mediaLibrary = new MediaLibrary();
      List<Picture>  pictures = new List<Picture>();
      Picture picture = null;
      for (int i = 0; i < _mediaLibrary.Pictures.Count; i++)
      {
        picture = _mediaLibrary.Pictures[i];
        pictures.Add(picture);
        if (i > 30)
          break;
      }

      callback(pictures, null);
      _mediaLibrary.Dispose();
    }
  }
}