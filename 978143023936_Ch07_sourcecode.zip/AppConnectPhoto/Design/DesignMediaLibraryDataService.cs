﻿using System;
using Microsoft.Xna.Framework.Media;
using System.Collections.Generic;
using AppConnectPhoto.Model;

namespace AppConnectPhoto.Design
{
  public class DesignMediaLibraryDataService : IMediaLibraryDataService
  {
    public void GetData(Action<List<Picture>, Exception> callback)
    {
      List<Picture> pictures = new List<Picture>()
      {
        //Cannot create Picture items - no constructor
      };
      callback(pictures, null);
    }
  }
}