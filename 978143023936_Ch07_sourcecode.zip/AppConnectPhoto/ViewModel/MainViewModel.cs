﻿using GalaSoft.MvvmLight;
using AppConnectPhoto.Model;
using Microsoft.Xna.Framework.Media;
using System.Collections.Generic;

namespace AppConnectPhoto.ViewModel
{
  public class MainViewModel : ViewModelBase
  {
    private readonly IMediaLibraryDataService _mediaLibraryService;

    public MainViewModel(IMediaLibraryDataService dataService)
    {
      _mediaLibraryService = dataService;
      _mediaLibraryService.GetData(
          (pictures, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }
            Pictures = (List<Picture>)pictures;
          });
      //Construct PictureEditingViewModel here so that it can receive
      //messages regarding which photo to display
      //PictureEditorView.xaml DataContext is set to this instance
      PictureEditingVM = new PictureEditingViewModel();
    }

    #region basic page properties
    public string ApplicationTitle
    {
      get
      {
        return "CHAPTER SEVEN";
      }
    }

    public string PageName
    {
      get
      {
        return "photos extra";
      }
    }
    #endregion

    #region Pictures Property
    public const string PicturesPropertyName = "Pictures";
    private List<Picture> _pictures = null;
    public List<Picture> Pictures
    {
      get
      {
        return _pictures;
      }

      set
      {
        if (_pictures == value)
        {
          return;
        }

        var oldValue = _pictures;
        _pictures = value;
        RaisePropertyChanged(PicturesPropertyName);
      }
    }
    #endregion

    /// <summary>
    /// The <see cref="PictureEditingVM" /> property's name.
    /// </summary>
    public const string PictureEditingVMPropertyName = "PictureEditingVM";

    private PictureEditingViewModel _pictureEditingVM = null;

    /// <summary>
    /// Sets and gets the PictureEditingVM property.
    /// Changes to that property's value raise the PropertyChanged event. 
    /// </summary>
    public PictureEditingViewModel PictureEditingVM
    {
      get
      {
        if (null == _pictureEditingVM)
          _pictureEditingVM = new PictureEditingViewModel();

        return _pictureEditingVM;
      }

      private set
      {
        if (_pictureEditingVM == value)
        {
          return;
        }

        _pictureEditingVM = value;
        RaisePropertyChanged(PictureEditingVMPropertyName);
      }
    }

    ////public override void Cleanup()
    ////{
    ////    // Clean up if needed

    ////    base.Cleanup();
    ////}
  }
}