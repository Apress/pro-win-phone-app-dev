﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.UserData;
using System.Data.Linq;

namespace ContactsAndCalendar.pages
{
  public partial class AppointmentDetails : PhoneApplicationPage
  {
    Appointment _appointment;
    public AppointmentDetails()
    {
      InitializeComponent();
    }

    protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);
      SearchHelperClass searchHelper = new SearchHelperClass();

      searchHelper.Subject = (string)NavigationContext.QueryString["Subject"];
      searchHelper.Location = (string)NavigationContext.QueryString["Location"];
    
      DateTime startTime = Convert.ToDateTime(
        NavigationContext.QueryString["StartTime"].ToString());      
      DateTime endTime = Convert.ToDateTime(
        NavigationContext.QueryString["EndTime"].ToString());
      //find apointment of interest;
      Appointments appointments = new Appointments();
      appointments.SearchCompleted += new EventHandler<AppointmentsSearchEventArgs>(appointments_SearchCompleted);
      appointments.SearchAsync(startTime, endTime, searchHelper);
    }

    void appointments_SearchCompleted(object sender, AppointmentsSearchEventArgs e)
    {
      SearchHelperClass searchelper = e.State as SearchHelperClass;
      var appointments = e.Results;
      if (appointments.Count() == 1)
        _appointment = appointments.First();
      else
      {
        var appointment = from a in appointments
                          where a.Subject == searchelper.Subject &&
                                a.Location == searchelper.Location
                          select a;
        _appointment = appointment.First();
      }
      ContentPanel.DataContext = _appointment;
    }
  }

  class SearchHelperClass
  {
    public string Subject;
    public string Location;
  }
}