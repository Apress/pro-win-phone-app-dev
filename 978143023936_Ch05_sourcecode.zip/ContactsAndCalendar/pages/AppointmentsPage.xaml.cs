﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.UserData;

namespace ContactsAndCalendar.pages
{
  public partial class AppointmentsPage : PhoneApplicationPage
  {
    Appointments _appointments;
    
    List<Appointment> _appointmentsList;
    DateTime _startTimeInclusive;
    DateTime _endTimeInclusive;

    public AppointmentsPage()
    {
      InitializeComponent();
      this.Loaded += new RoutedEventHandler(CalendarPage_Loaded);
    }

    void CalendarPage_Loaded(object sender, RoutedEventArgs e)
    {
      _appointments = new Appointments();
      _appointments.SearchCompleted += new EventHandler<AppointmentsSearchEventArgs>(_appointments_SearchCompleted);
      //Initialize filter
      _startTimeInclusive = DateTime.Now - TimeSpan.FromDays(30);
      _endTimeInclusive = DateTime.Now;
      //Retreive contacts
      RefreshAppBarBtn_Click(sender, e); 
    }

    void  _appointments_SearchCompleted(object sender, AppointmentsSearchEventArgs e)
    {
      _appointmentsList = e.Results.ToList<Appointment>();
      appointmentListBox.ItemsSource = _appointmentsList;
 	    calendarLoadProgressBar.Visibility = Visibility.Collapsed;
    }

    private void calendarListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (e.AddedItems.Count > 0)
      {
        Appointment appnt = (Appointment)e.AddedItems[0];
        NavigationService.Navigate(new Uri("/pages/AppointmentDetails.xaml?Subject="
          + appnt.Subject
          + "&StartTime=" + appnt.StartTime
          + "&EndTime=" + appnt.EndTime
          + "&Location=" + appnt.Location, UriKind.Relative));
      }
    }

    private void RefreshAppBarBtn_Click(object sender, EventArgs e)
    {
      calendarLoadProgressBar.Visibility = Visibility.Visible;
      //Get appointments based on filter
      _appointments.SearchAsync(_startTimeInclusive, _endTimeInclusive, null);
    }

    private void FilterAppBarBtn_Click(object sender, EventArgs e)
    {
      //Initialize filter values
      StartDateFilterTextBox.Text = _startTimeInclusive.ToShortDateString();
      EndDateFilterTextBox.Text = _endTimeInclusive.ToShortDateString();
      //Hide the app bar to prevent the user from accessing the buttons
      this.ApplicationBar.IsVisible = false;
      //Show filter dialog
      gridFilterAppointments.Visibility = Visibility.Visible;
    }

    protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
    {
      //Correct method to close a dialog on Windows Phone is the Back Key
      //Need to determine if dialog is visible to prevent page
      //back navigation
      if (gridFilterAppointments.Visibility == Visibility.Visible)
      {
        gridFilterAppointments.Visibility = Visibility.Collapsed;
        //Update Filter
        if (StartDateFilterTextBox.Text != String.Empty)
          _startTimeInclusive = Convert.ToDateTime(StartDateFilterTextBox.Text);
        if (EndDateFilterTextBox.Text != String.Empty)
          _endTimeInclusive = Convert.ToDateTime(EndDateFilterTextBox.Text);
        //Refresh appointments based on filter
        RefreshAppBarBtn_Click(gridFilterAppointments, e);
        //Show App Bar
        this.ApplicationBar.IsVisible = true;
        //Cancel back navigation
        e.Cancel = true;
      }
      base.OnBackKeyPress(e);
    }
  }
}