﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.UserData;

namespace ContactsAndCalendar.pages
{
  public partial class ContactsPage : PhoneApplicationPage
  {
    Contacts _contacts;

    string _contactsFilter;
    List<Contact> _contactsList;

    public ContactsPage()
    {
      InitializeComponent();
      this.Loaded += new RoutedEventHandler(ContactsPage_Loaded);
    }

void ContactsPage_Loaded(object sender, RoutedEventArgs e)
{
  _contacts = new Contacts();
  _contacts.SearchCompleted += new EventHandler<ContactsSearchEventArgs>(_contacts_SearchCompleted);
  //Apply initial filter on contacts
  _contactsFilter = String.Empty;
  //Refresh contact list
  RefreshAppBarBtn_Click(sender, e);
}

void _contacts_SearchCompleted(object sender, ContactsSearchEventArgs e)
{
  _contactsList = e.Results.ToList<Contact>();
  contactsListBox.ItemsSource = _contactsList;
  contactsLoadProgressBar.Visibility = Visibility.Collapsed;
}

private void contactsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
{
  if (e.AddedItems.Count > 0)
  {
    Contact contact = (Contact)e.AddedItems[0];
    NavigationService.Navigate(new Uri("/pages/ContactDetails.xaml?DisplayName=" + contact.DisplayName, UriKind.Relative));
  }
}

    private void RefreshAppBarBtn_Click(object sender, EventArgs e)
    {
      contactsLoadProgressBar.Visibility = Visibility.Visible;
      //Retrieve contacts based on filter
      _contacts.SearchAsync(_contactsFilter, FilterKind.DisplayName, null); 
    }

    private void FilterAppBarBtn_Click(object sender, EventArgs e)
    {
      //Initialize filter values for dialog
      filterTextBox.Text = _contactsFilter;
      //Hide the app bar to prevent the user from accessing the buttons
      this.ApplicationBar.IsVisible = false;
      //Show fitler dialog
      gridFilterContacts.Visibility = Visibility.Visible;
    }

    protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
    {
      //Correct method to close a dialog on Windows Phone is the Back Key
      //Need to determine if dialog is visible to prevent page
      //back navigation
      if (gridFilterContacts.Visibility == Visibility.Visible)
      {
        gridFilterContacts.Visibility = Visibility.Collapsed;
        //Update filter
        _contactsFilter = filterTextBox.Text;
        //refresh contacts based on filter
        RefreshAppBarBtn_Click(gridFilterContacts, e);
        //Show App Bar
        this.ApplicationBar.IsVisible = true;
        //Cancel back navigation
        e.Cancel = true;
      }
      base.OnBackKeyPress(e);
    }
  }
}