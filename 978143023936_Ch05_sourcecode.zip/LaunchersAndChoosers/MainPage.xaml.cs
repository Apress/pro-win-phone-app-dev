﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
//Namespaces added
using Microsoft.Phone.Tasks;
using System.Text;
using System.Windows.Media.Imaging;
using System.Device.Location;

namespace LaunchersAndChoosers
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }
    #region Email Compose Task
    private void EmailComposeTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      //cause an exception and then send an error report.
      try
      {
        int num1 = 3;
        int num2 = 3;
        int num3 = num1 / (num1 - num2);
      }
      catch (Exception err)
      {
        EmailComposeTask task = new EmailComposeTask();
        task.To = "support@WP7isv.com";
        task.Subject = "Customer Error Report";
        //Size StringBuilder appropriately
        StringBuilder builder;
        if (null == err.InnerException)
          builder = new StringBuilder(600);
        else //need space for InnerException
          builder = new StringBuilder(1200);
        builder.AppendLine("Please tell us what you were doing when the problem occurred.\n\n\n");
        builder.AppendLine("EXCEPTION DETAILS:");
        builder.Append("message:");
        builder.AppendLine(err.Message);
        builder.AppendLine("");
        builder.Append("stack trace:");
        builder.AppendLine(err.StackTrace);
        if (null != err.InnerException)
        {
          builder.AppendLine("");
          builder.AppendLine("");
          builder.AppendLine("inner exception:");
          builder.Append("inner exception message:");
          builder.AppendLine(err.InnerException.Message);
          builder.AppendLine("");
          builder.Append("inner exception stack trace:");
          builder.AppendLine(err.InnerException.StackTrace);
        }
        task.Body = builder.ToString();
        task.Show();
      }
    }
    #endregion

    #region Marketplace Tasks
    private void MarketplaceHubTask1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      MarketplaceHubTask marketplaceHubTask = new MarketplaceHubTask();
      marketplaceHubTask.ContentType = MarketplaceContentType.Applications;
      marketplaceHubTask.Show();
    }

    private void MarketplaceHubTask2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      MarketplaceHubTask marketplaceHubTask = new MarketplaceHubTask();
      marketplaceHubTask.ContentType = MarketplaceContentType.Music;
      marketplaceHubTask.Show();
    }

    private void MarketplaceSearchTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      MarketplaceSearchTask marketplaceSearchTask = new MarketplaceSearchTask();
      marketplaceSearchTask.ContentType = MarketplaceContentType.Music;
      marketplaceSearchTask.SearchTerms = "driving music";
      marketplaceSearchTask.Show();
    }

    private void MarketplaceDetailTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      MarketplaceDetailTask marketplaceDetailTask = new MarketplaceDetailTask();
      marketplaceDetailTask.ContentType = MarketplaceContentType.Applications;
      //AppID for the youtube application
      marketplaceDetailTask.ContentIdentifier = "dcbb1ac6-a89a-df11-a490-00237de2db9e";
      marketplaceDetailTask.Show();
    }

    private void MarketplaceReviewTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      MarketplaceReviewTask marketplaceReviewTask = new MarketplaceReviewTask();
      marketplaceReviewTask.Show();
    }
    #endregion

    #region Media Player Launcher Task
    private void MediaPlayerLauncher_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      MediaPlayerLauncher mediaPlayerLauncher = new MediaPlayerLauncher();
      mediaPlayerLauncher.Controls = MediaPlaybackControls.FastForward |
        MediaPlaybackControls.Pause | MediaPlaybackControls.Rewind |
        MediaPlaybackControls.Skip | MediaPlaybackControls.Stop;
      mediaPlayerLauncher.Location = MediaLocationType.Data;
      mediaPlayerLauncher.Media = new Uri("http://ecn.channel9.msdn.com/o9/ch9/8/9/6/6/3/5/WP7Xbox_ch9.mp4");
      mediaPlayerLauncher.Show();
    }
    #endregion

    #region Phone Call Task
    private void PhoneCallTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      PhoneCallTask phoneCallTask = new PhoneCallTask();
      phoneCallTask.DisplayName = "Rob Cameron";
      phoneCallTask.PhoneNumber = "555-555-1111";
      phoneCallTask.Show();
    }
    #endregion

    #region Bing Search Task
    private void SearchTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SearchTask searchTask = new SearchTask();
      searchTask.SearchQuery = "driving music";
      searchTask.Show();
    }
    #endregion

    #region SMS Compose Task
    private void SMSComposeTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      Microsoft.Phone.Tasks.SmsComposeTask smsComposeTask = new SmsComposeTask();
      smsComposeTask.To = "555-555-5555";
      smsComposeTask.Body = "Meet me for pizza.";
      smsComposeTask.Show();
    }
    #endregion

    #region Web Browser Task
    private void WebBrowserTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      WebBrowserTask webBrowserTask = new WebBrowserTask();
      webBrowserTask.Uri = new Uri("http://create.msdn.com");
      webBrowserTask.Show();
    }
    #endregion

    #region Email Address Chooser
    private void EmailAddressChooserTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      EmailAddressChooserTask emailAddressChooserTask = new EmailAddressChooserTask();
      emailAddressChooserTask.Completed += new EventHandler<EmailResult>(emailAddressChooserTask_Completed);
      emailAddressChooserTask.Show();
    }

    void emailAddressChooserTask_Completed(object sender, EmailResult e)
    {
      if ((null == e.Error) && (TaskResult.OK == e.TaskResult))
      {
        MessageBox.Show("Email address returned is: " + e.Email);
      }
    }
    #endregion

    #region Phone Number  Chooser
    private void PhoneNumberChooserTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      PhoneNumberChooserTask phoneNumberChooserTask = new PhoneNumberChooserTask();
      phoneNumberChooserTask.Completed += new EventHandler<PhoneNumberResult>(phoneNumberChooserTask_Completed);
      phoneNumberChooserTask.Show();
    }

    void phoneNumberChooserTask_Completed(object sender, PhoneNumberResult e)
    {
      if ((null == e.Error) && (TaskResult.OK == e.TaskResult))
      {
        MessageBox.Show("Phone number returned is: " + e.PhoneNumber);
      }
    }
    #endregion

    #region Photo Chooser Task
    private void PhotoChooserTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      PhotoChooserTask photoChoserTask = new PhotoChooserTask();
      photoChoserTask.ShowCamera = true;
      photoChoserTask.Completed += new EventHandler<PhotoResult>(photoChoserTask_Completed);
      photoChoserTask.Show();
    }

    private BitmapImage capturedImage;
    void photoChoserTask_Completed(object sender, PhotoResult e)
    {
      if ((null == e.Error) && (TaskResult.OK == e.TaskResult))
      {
        capturedImage = new BitmapImage();
        capturedImage.SetSource(e.ChosenPhoto);
        ChosenPhotoImage.Source = capturedImage;
      }
    }
    #endregion

    #region Save Email Address Task
    private void SaveEmailAdressTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SaveEmailAddressTask saveEmailAddressTask = new SaveEmailAddressTask();
      saveEmailAddressTask.Completed += new EventHandler<TaskEventArgs>(saveEmailAddressTask_Completed);
      saveEmailAddressTask.Email = "email@domain.com";
      MessageBox.Show("Saving this email: " + saveEmailAddressTask.Email);
      saveEmailAddressTask.Show();
    }

    void saveEmailAddressTask_Completed(object sender, TaskEventArgs e)
    {
      if ((null == e.Error) && (TaskResult.OK == e.TaskResult))
      {
        MessageBox.Show("Email address saved");
      }
    }
    #endregion

    #region Save Phone Number Task
    private void SavePhoneNumberTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SavePhoneNumberTask savePhoneNumberTask = new SavePhoneNumberTask();
      savePhoneNumberTask.Completed += new EventHandler<TaskEventArgs>(savePhoneNumberTask_Completed);
      savePhoneNumberTask.PhoneNumber = "555-555-5555";
      MessageBox.Show("Saving this phone number: " + savePhoneNumberTask.PhoneNumber);
      savePhoneNumberTask.Show();
    }

    void savePhoneNumberTask_Completed(object sender, TaskEventArgs e)
    {
      if ((null == e.Error) && (TaskResult.OK == e.TaskResult))
      {
        MessageBox.Show("Phone number saved");
      }
    }
    #endregion

    #region Bing Maps Directions Task
    private void BingMapsDirectionsTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      BingMapsDirectionsTask task = new BingMapsDirectionsTask();
      //Use the Windows Phone user's current location as Start by not 
      //specifying a Start location on the BingMapsDirectionsTask instance
      //Use location simulation in the Emulator to help you test
      //Use a search term of "Gwinnett Arena" as the End location.  
      //Leave GeoCoordinate location value as null to have Bing first find the location
      LabeledMapLocation DirectionsEndPoint = new LabeledMapLocation();
      DirectionsEndPoint.Label = "Gwinnett Arena";

      //or pass in a geolocation...
     // LabeledMapLocation DirectionsEndPoint = new LabeledMapLocation("Gwinnett Arena", 
     //   new GeoCoordinate(33, 98764, -84.09148));

      task.End = DirectionsEndPoint;
      task.Show();
    }
    #endregion

    #region Bing Maps Search Task
    private void BingMapsTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      BingMapsTask task = new BingMapsTask();
      //Search for restaurants near the Gwinnett Arena
      //Leave the Center property blank to use the user's current location
      //Use location simulation in the Emulator to help you test
      task.Center = new GeoCoordinate(33.98764, -84.09148);
      task.SearchTerm = "restaurants";
      task.Show();
    }
    #endregion

    #region Connection Settings Task
    private void ConnectionSettingsTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      ConnectionSettingsTask task = new ConnectionSettingsTask();
      //Other options besides WiFi are AirplaneMode, Bluetooth, and Cellular
      task.ConnectionSettingsType = ConnectionSettingsType.WiFi;
      task.Show();
    }
    #endregion

    #region Share Link via Social Network Task
private void ShareLinkTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
{
  ShareLinkTask task = new ShareLinkTask();
  task.LinkUri = new Uri("http://www.windowsphone.com");
  task.Title = "Check out Windows Phone.";
  task.Message = "Now in the Mango edition:-)";
  task.Show();
}
    #endregion

    #region Share Status via Social Network Task
    private void ShareStatusTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      ShareStatusTask task = new ShareStatusTask();
      task.Status = "Check out Windows Phone";
      task.Show();
    }
    #endregion

    #region Address Chooser Task
    private void AddressChooserTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      AddressChooserTask task = new AddressChooserTask();
      task.Completed += new EventHandler<AddressResult>(task_Completed);
      task.Show();
    }

    void task_Completed(object sender, AddressResult e)
    {
      if (e.TaskResult == TaskResult.OK)
      {
        MessageBox.Show("Display Name: " + e.DisplayName +
          "\n Address: " + e.Address);
      }
      else
        MessageBox.Show("No address was selected: "+e.Error);
    }
    #endregion

    #region Save Contact Task
    private void SaveContactTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SaveContactTask task = new SaveContactTask();
      task.Completed += new EventHandler<SaveContactResult>(task_Completed);
      //A few properties available are populated below
      //Full contact data fields are available
      task.Company = "Test Company";
      task.FirstName = "Robert";
      task.LastName = "Cameron";
      task.HomePhone = "555-555-1111";
      task.WorkPhone = "555-555-2222";
      task.Website = "http://blogs.msdn.com/robcamer";
      task.JobTitle = "Author";
      task.Nickname = "Rob";
      task.PersonalEmail = "test@personalemail.com";
      task.WorkEmail = "test@test.com";
      task.MobilePhone = "555-555-3333";
      task.Show();
    }

    void task_Completed(object sender, SaveContactResult e)
    {
      if (e.TaskResult == TaskResult.OK)
        MessageBox.Show("Contact saved.");
      else
        MessageBox.Show("Error saving contact: " + e.Error);
    }
    #endregion

    #region Save Ringtone Task
    private void SaveRintoneTask_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      SaveRingtoneTask task = new SaveRingtoneTask();
      task.Completed += new EventHandler<TaskEventArgs>(task_Completed);
      task.DisplayName = "My Fav Ringtone";
      task.IsShareable = true; //shareable with other applications
      task.Source = new Uri("appdata:/Ringtone 01.wma");
      task.Show();
    }

    void task_Completed(object sender, TaskEventArgs e)
    {
      if (e.TaskResult == TaskResult.OK)
        MessageBox.Show("Ringtone saved.");
      else
        MessageBox.Show("Error savign Rington: " + e.Error);
    }
    #endregion
  }
}