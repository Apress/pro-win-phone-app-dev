﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;

namespace AlarmsAndReminders
{
  public partial class MainPage : PhoneApplicationPage
  {
    IEnumerable<ScheduledNotification> _notifications;

    // Constructor
    public MainPage()
    {
      InitializeComponent();
      Loaded += new RoutedEventHandler(MainPage_Loaded);
    }

    void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
      RefreshScheduledNotificationsList();
    }

    private void RefreshScheduledNotificationsList()
    {
      _notifications = ScheduledActionService.GetActions<ScheduledNotification>();
      NotificationListBox.ItemsSource = _notifications;

      if (_notifications.Count<ScheduledNotification>() > 0)
      {
        EmptyTextBlock.Visibility = Visibility.Collapsed;
      }
      else
      {
        EmptyTextBlock.Visibility = Visibility.Visible;
      }
    }

    private void deleteNotificationButton_Click(object sender, RoutedEventArgs e)
    {
      // The scheduled action name is stored in the Tag property
      // of the delete button for each notification
      string name = (string)((Button)sender).Tag;

      // Call Remove to unregister the scheduled notification with the service.
      ScheduledActionService.Remove(name);

      // Reset the NotificationListBox items
      RefreshScheduledNotificationsList();
    }

    private void CreateTextButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      String name = System.Guid.NewGuid().ToString();
      DateTime date = (DateTime)beginDatePicker.Value;
      DateTime time = (DateTime)beginTimePicker.Value;
      DateTime beginTime = date + time.TimeOfDay;

      // Make sure that the begin time has not already passed.
      if (beginTime < DateTime.Now)
      {
        MessageBox.Show("The begin date must be in the future.");
        return;
      }

      // Get the expiration time for the notification.
      date = (DateTime)expirationDatePicker.Value;
      time = (DateTime)expirationTimePicker.Value;
      DateTime expirationTime = date + time.TimeOfDay;

      // Make sure that the expiration time is after the begin time.
      if (expirationTime < beginTime)
      {
        MessageBox.Show("Expiration time must be after the begin time.");
        return;
      }
      // Determine which recurrence radio button is checked.
      RecurrenceInterval recurrence = RecurrenceInterval.None;
      if (dailyRadioButton.IsChecked == true)
      {
        recurrence = RecurrenceInterval.Daily;
      }
      else if (weeklyRadioButton.IsChecked == true)
      {
        recurrence = RecurrenceInterval.Weekly;
      }
      else if (monthlyRadioButton.IsChecked == true)
      {
        recurrence = RecurrenceInterval.Monthly;
      }
      else if (endOfMonthRadioButton.IsChecked == true)
      {
        recurrence = RecurrenceInterval.EndOfMonth;
      }
      else if (yearlyRadioButton.IsChecked == true)
      {
        recurrence = RecurrenceInterval.Yearly;
      }

      string param1Value = param1TextBox.Text;
      string param2Value = param2TextBox.Text;
      string queryString = "";
      if (param1Value != "" && param2Value != "")
      {
        queryString = "?param1=" + param1Value + "&param2=" + param2Value;
      }
      else if (param1Value != "" || param2Value != "")
      {
        queryString = (param1Value != null) ? "?param1=" + param1Value : "?param2=" + param2Value;
      }
      Uri navigationUri = new Uri("/ReminderDeepLinkPage.xaml" + queryString, UriKind.Relative);

      if ((bool)reminderRadioButton.IsChecked)
      {
        Reminder reminder = new Reminder(name);
        reminder.Title = titleTextBox.Text;
        reminder.Content = contentTextBox.Text;
        reminder.BeginTime = beginTime;
        reminder.ExpirationTime = expirationTime;
        reminder.RecurrenceType = recurrence;
        reminder.NavigationUri = navigationUri;

        // Register the reminder with the system.
        ScheduledActionService.Add(reminder);
      }
      else
      {
        Alarm alarm = new Alarm(name);
        alarm.Content = contentTextBox.Text;
        alarm.Sound = new Uri("/Ringtone 07.wma", UriKind.Relative);
        alarm.BeginTime = beginTime;
        alarm.ExpirationTime = expirationTime;
        alarm.RecurrenceType = recurrence;

        ScheduledActionService.Add(alarm);
      }
      //Since save clicked, close dialog and refresh list
      AddNotificationGrid.Visibility = Visibility.Collapsed;
      ApplicationBar.IsVisible = true;
      RefreshScheduledNotificationsList();
    }

    private void AddNotificationBtn_Click(object sender, EventArgs e)
    {
      ApplicationBar.IsVisible = false;
      AddNotificationGrid.Visibility = Visibility.Visible;
    }

    protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
    {
      if (AddNotificationGrid.Visibility == Visibility.Visible)
      {
        AddNotificationGrid.Visibility = Visibility.Collapsed;
        ApplicationBar.IsVisible = true;
        e.Cancel = true;
      }
      base.OnBackKeyPress(e);
    }
  }
}