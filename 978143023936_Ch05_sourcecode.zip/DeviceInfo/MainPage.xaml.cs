﻿using System;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Windows.Threading;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Info;
using Microsoft.Phone.Marketplace;
using Microsoft.Phone.Net.NetworkInformation;
using PhoneNetworkApi = Microsoft.Phone.Net.NetworkInformation;

namespace DeviceInfo
{
  public partial class MainPage : PhoneApplicationPage
  {
    DispatcherTimer timer;
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void PhoneApplicationPage_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
      timer = new DispatcherTimer();
      timer.Interval = TimeSpan.FromSeconds(.001);
      timer.Tick += new EventHandler(timer_Tick);
      timer.Tick += new EventHandler(DebugMemoryInfo_Tick);
      timer.Start();

      RetrieveIdentityValues();
      RetrieveDeviceInfo();
      RetrieveSystemEnvironmentInfo();
      SetupNetworkStatusCheck();
      ApplicationLicenseAndTrialInfo();
      RetrieveNetworkInfo();
      EstablishSocketConnectionAndCheckNetwork();
    }

    void timer_Tick(object sender, EventArgs e)
    {
      DeviceTotalMemoryTextBlock.Text = (DeviceStatus.DeviceTotalMemory / (1024 * 1024)).ToString() + "MB";
      ApplicationCurrentMemoryUsageTextBlock.Text = (DeviceStatus.ApplicationCurrentMemoryUsage / (1024 * 1024)).ToString() + "MB";
      ApplicationPeakMemoryUsageTextBlock.Text = (DeviceStatus.ApplicationPeakMemoryUsage / (1024 * 1024)).ToString() + "MB";
      ApplicationMaxMemoryLimitTextBlock.Text = (DeviceStatus.ApplicationMemoryUsageLimit / (1024 * 1024)).ToString() + "MB";
    }

    #region Retrieve Identity
    private void RetrieveIdentityValues()
    {
      object deviceID;
      object userID;

      if (!Microsoft.Phone.Info.DeviceExtendedProperties.TryGetValue("DeviceUniqueID", out deviceID))
        DeviceIDTextBlock.Text = "Error retrieving Device iD";
      else
        DeviceIDTextBlock.Text = (string)deviceID;

      if (!Microsoft.Phone.Info.UserExtendedProperties.TryGetValue("ANID", out userID))
        UserIDTextBlock.Text = "Error retrieving User iD";
      else
        UserIDTextBlock.Text = (string)userID;
    }
    #endregion

    #region DeviceInfo
    private void RetrieveDeviceInfo()
    {
      DeviceManufacturerTextBlock.Text = DeviceStatus.DeviceManufacturer;
      DeviceNameTextBlock.Text = DeviceStatus.DeviceName;
      DeviceFirmwareVersionTextBlock.Text = DeviceStatus.DeviceFirmwareVersion;
      DeviceHardwareVersionTextBlock.Text = DeviceStatus.DeviceHardwareVersion;

      DeviceStatus.PowerSourceChanged += new EventHandler(DeviceStatus_PowerSourceChanged);
      PowerSourceTextBlock.Text = DeviceStatus.PowerSource.ToString();

      DeviceStatus.KeyboardDeployedChanged += DeviceStatus_KeyboardDeployedChanged;
      if (DeviceStatus.IsKeyboardPresent)
        KeyboardAvailTextBlock.Text = "true";
      else
        KeyboardAvailTextBlock.Text = "false";
      if (DeviceStatus.IsKeyboardDeployed)
        KeyboardDeployedTextBlock.Text = "true";
      else
        KeyboardDeployedTextBlock.Text = "false";
    }

    void DeviceStatus_PowerSourceChanged(object sender, EventArgs e)
    {
      PowerSourceTextBlock.Text = DeviceStatus.PowerSource.ToString();
    }

    void DeviceStatus_KeyboardDeployedChanged(object sender, EventArgs e)
    {
      Dispatcher.BeginInvoke(() =>
      {
        if (DeviceStatus.IsKeyboardDeployed)
          KeyboardDeployedTextBlock.Text = "true";
        else
          KeyboardDeployedTextBlock.Text = "false";
      });
    }
    #endregion

    #region Environment Info
    private void RetrieveSystemEnvironmentInfo()
    {
      try
      {
        CurrentDirectoryTextBlock.Text = Environment.CurrentDirectory;
      }
      catch
      {
        CurrentDirectoryTextBlock.Text = "Cannot access current directory";
      }
      HasShutdownStartedTextBlock.Text = Environment.HasShutdownStarted.ToString();
      OSVersionPlatformTextBlock.Text = Environment.OSVersion.Platform.ToString();
      OSVersionVersionTextBlock.Text = Environment.OSVersion.Version.ToString();
      TickCountTextBlock.Text = Environment.TickCount.ToString();
      CLRVersionTextBlock.Text = Environment.Version.ToString();

    }
    #endregion

    #region Network Info
    private void RetrieveNetworkInfo()
    {
      MobileOperatorTextBlock.Text =
        PhoneNetworkApi.DeviceNetworkInformation.CellularMobileOperator;
      CellDataEnabledTextBlock.Text =
        PhoneNetworkApi.DeviceNetworkInformation.IsCellularDataEnabled.ToString();
      RoamingDataEnabledTextBlock.Text =
        PhoneNetworkApi.DeviceNetworkInformation.IsCellularDataRoamingEnabled.ToString();
      WiFiDataEnabledTextBlock.Text =
        PhoneNetworkApi.DeviceNetworkInformation.IsWiFiEnabled.ToString();
    }
    #endregion

    #region Network Status Check
    private void SetupNetworkStatusCheck()
    {
      NetworkChange.NetworkAddressChanged +=
        new NetworkAddressChangedEventHandler
            (NetworkChange_NetworkAddressChanged);
      //Initialize values
      NetworkAvailableTextBlock.Text =
        PhoneNetworkApi.NetworkInterface.GetIsNetworkAvailable().ToString();
      NetworkConnectionTextBlock.Text =
        PhoneNetworkApi.NetworkInterface.NetworkInterfaceType.ToString();
    }

    void NetworkChange_NetworkAddressChanged(object sender, EventArgs e)
    {
      NetworkAvailableTextBlock.Text =
        PhoneNetworkApi.NetworkInterface.GetIsNetworkAvailable().ToString();
      NetworkConnectionTextBlock.Text =
        PhoneNetworkApi.NetworkInterface.NetworkInterfaceType.ToString();
    }
    #endregion

#region Socket Network Status Check
    private void EstablishSocketConnectionAndCheckNetwork()
    {
      Socket socket = 
        new Socket(AddressFamily.InterNetwork, SocketType.Stream, 
          ProtocolType.Tcp);
      string serverName = "192.168.0.119";
      int portNumber = 7;
      //create DNS end point
      DnsEndPoint hostEntry = new DnsEndPoint(serverName, portNumber);
      
      //Create Event args and w.ire up completed event
      SocketAsyncEventArgs socketEventArg = new SocketAsyncEventArgs();
      socketEventArg.RemoteEndPoint = hostEntry;
      socketEventArg.UserToken = socket;
      socketEventArg.Completed += new EventHandler<SocketAsyncEventArgs>(socketEventArg_Completed);
      
      //Connect to the socket
      socket.ConnectAsync(socketEventArg);
    }

    void socketEventArg_Completed(object sender, SocketAsyncEventArgs e)
    {
      // When ConnectAsync is called, the socket object is passe in as part
      // of the socketEventArg UserToken value. 
      Socket socket = e.UserToken as Socket;
      if (e.SocketError == SocketError.Success)
      {
        PhoneNetworkApi.NetworkInterfaceInfo netInterfaceInfo = 
          socket.GetCurrentNetworkInterface();
        Dispatcher.BeginInvoke(() =>
        {
          SocketInterfaceNameTextBlock.Text = netInterfaceInfo.InterfaceName;
          SocketInterfaceNameTextBlock.Text = netInterfaceInfo.InterfaceName;
          SocketNetworkStateTextBlock.Text = netInterfaceInfo.InterfaceState.ToString();
          SocketNetworkTypeTextBlock.Text = netInterfaceInfo.InterfaceType.ToString();
          SocketNetworkSubTypeTextBlock.Text = netInterfaceInfo.InterfaceSubtype.ToString();
        });
      }
    }
#endregion

    #region License and Trial Info
    private void ApplicationLicenseAndTrialInfo()
    {
      Microsoft.Phone.Marketplace.LicenseInformation licenseInformation = new LicenseInformation();
      IsTrialTextBlock.Text = licenseInformation.IsTrial().ToString();
    }
    #endregion

    void DebugMemoryInfo_Tick(object sender, EventArgs e)
    {
      System.Diagnostics.Debug.WriteLine("<------------------->");
      //GC.GetTotalMemory(true);
      string deviceTotalMemory =
        (DeviceStatus.DeviceTotalMemory / (1024 * 1024)).ToString() + "MB";
      string applicationCurrentMemoryUsage =
        (DeviceStatus.ApplicationCurrentMemoryUsage / (1024 * 1024)).ToString() + "MB";
      string applicationPeakMemoryUsage =
      (DeviceStatus.ApplicationPeakMemoryUsage / (1024 * 1024)).ToString() + "MB";
      System.Diagnostics.Debug.WriteLine("--> " +
        DateTime.Now.ToLongTimeString());
      System.Diagnostics.Debug.WriteLine("--> Device Total : " +
        deviceTotalMemory);
      System.Diagnostics.Debug.WriteLine("--> App Current : " +
        applicationCurrentMemoryUsage);
      System.Diagnostics.Debug.WriteLine("--> App Peak : " +
        applicationPeakMemoryUsage);
      System.Diagnostics.Debug.WriteLine("");
    }
  }
}