﻿using System;
using System.ComponentModel;
using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace SharedGraphicsBackground.helper
{
  public class RichBackgroundBasePage : PhoneApplicationPage
  {
    GameTimer gameTimer;
    SpriteBatch spriteBatch;
    UIElementRenderer uiElementRenderer;
    GraphicsDevice graphicsDevice;

    public RichBackgroundBasePage()
    {
      if (!DesignerProperties.IsInDesignTool)
      {
        graphicsDevice = SharedGraphicsDeviceManager.Current.GraphicsDevice;
        spriteBatch = new SpriteBatch(graphicsDevice);
        // Create a timer for this page
        gameTimer = new GameTimer();
        gameTimer.UpdateInterval = TimeSpan.FromTicks(333333);
        gameTimer.Update += OnUpdate;
        gameTimer.Draw += OnDraw;
      }
    }

    private void OnUpdate(object sender, GameTimerEventArgs e)
    {
      RichBackgroundRenderer.Current.Update(e.ElapsedTime, e.TotalTime);
    }

    private void OnDraw(object sender, GameTimerEventArgs e)
    {
      SharedGraphicsDeviceManager.Current.GraphicsDevice.Clear(
        Microsoft.Xna.Framework.Color.CornflowerBlue);

      // Render the Silverlight page to a texture
      uiElementRenderer.Render();
      RichBackgroundRenderer.Current.Draw();

      // Draw the Silverlight page generated texture
      spriteBatch.Begin();
      spriteBatch.Draw(uiElementRenderer.Texture, Vector2.Zero,
        Microsoft.Xna.Framework.Color.White);
      spriteBatch.End();
    }

    private void OnLayoutUpdated(object sender, EventArgs e)
    {
      // As before, the rendered XAML must have a width and height greater than 0
      if (ActualWidth > 0 && ActualHeight > 0)
      {
        //Check to see if the XAML to be rendered has changed size
        if (uiElementRenderer == null ||
            uiElementRenderer.Texture.Width != (int)ActualWidth ||
            uiElementRenderer.Texture.Height != (int)ActualHeight)
        {
          //Only create a new UIElementRenderer if necessary
          if (uiElementRenderer != null && uiElementRenderer.Texture != null)
            uiElementRenderer.Texture.Dispose();
          uiElementRenderer = new UIElementRenderer(
            this, (int)ActualWidth, (int)ActualHeight);
        }
      }
    }

    protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (!DesignerProperties.IsInDesignTool)
      {
        // Hook the LayoutUpdated to know when the page has calculated its layout
        LayoutUpdated += OnLayoutUpdated;
        gameTimer.Start();
      }
      base.OnNavigatedTo(e);
    }

    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (!DesignerProperties.IsInDesignTool)
      {
        gameTimer.Stop();
      }
      base.OnNavigatedFrom(e);
    }
  }
}