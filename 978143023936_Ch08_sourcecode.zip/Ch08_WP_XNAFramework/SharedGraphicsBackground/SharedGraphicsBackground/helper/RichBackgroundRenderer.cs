﻿using System;
using System.Windows;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using SharedGraphicsBackgrond;

namespace SharedGraphicsBackground.helper
{
  //Be sure to add this class to App.xaml in the <Application.ApplicationLifetimeObjects> 
  //element after the graphics adapter is created
  public class RichBackgroundRenderer : IApplicationService, IApplicationLifetimeAware
  {
    GraphicsDevice graphicsDevice;
    SpriteBatch spriteBatch;

    //book graphic fields
    Texture2D bookTexture;
    Vector2 bookPosition;
    Vector2 bookVelocity;

    public static RichBackgroundRenderer Current { get; private set; }

    //Constructor
    public RichBackgroundRenderer()
    {
      //There can be only one
      if (null != Current)
        throw new InvalidOperationException();

      Current = this;
    }

    public void Update(TimeSpan elapsedTime, TimeSpan totalTime)
    {
      //Rich background cotent game loop update code goes here
      bookPosition += bookVelocity;
      if (bookPosition.Y > 800d)
      {
        bookPosition.X = graphicsDevice.Viewport.Width / 2 - bookTexture.Width / 2;
        bookPosition.Y = -bookTexture.Height;
      }
    }

    public void Draw()
    {
      //Rich background content game loop draw code goes here
      spriteBatch.Begin();
      spriteBatch.Draw(bookTexture, bookPosition, Color.White);
      spriteBatch.End();
    }

    #region IApplicationService Implementation
    void IApplicationService.StartService(ApplicationServiceContext context)
    {

    }

    void IApplicationService.StopService()
    {

    }
    #endregion

    #region IApplicationLifetimeAware
    //Implemented
    void IApplicationLifetimeAware.Exited()
    {
      //clean up
      SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(false);
      spriteBatch.Dispose();
    }

    void IApplicationLifetimeAware.Exiting()
    {

    }

    //Implemented
    void IApplicationLifetimeAware.Started()
    {
      graphicsDevice = SharedGraphicsDeviceManager.Current.GraphicsDevice ;
      graphicsDevice.SetSharingMode(true);

      spriteBatch = new SpriteBatch(graphicsDevice);

      //Load rich background content
      ContentManager content = (Application.Current as App).Content;
      bookTexture = content.Load<Texture2D>("textures/book");
      bookPosition = new Vector2(graphicsDevice.Viewport.Width / 2 - bookTexture.Width / 2, -bookTexture.Height);
      bookVelocity = new Vector2(0, 4);
    }

    void IApplicationLifetimeAware.Starting()
    {

    }
    #endregion;
  }
}
