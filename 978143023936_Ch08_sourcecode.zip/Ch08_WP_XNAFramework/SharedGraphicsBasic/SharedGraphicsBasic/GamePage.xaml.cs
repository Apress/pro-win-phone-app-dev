﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input.Touch;

namespace SharedGraphicsBasic
{
    public partial class GamePage : PhoneApplicationPage
    {
        ContentManager contentManager;
        GameTimer timer;
        SpriteBatch spriteBatch;

        GestureSample gestureSample;
        string gestureInfo;
        SpriteFont spriteFontSegoeUIMono;
        Vector2 spriteFontDrawLocation;
        Texture2D StickManTexture;
        GameObject StickManGameObject;

        public GamePage()
        {
            InitializeComponent();

            // Get the content manager from the application
            contentManager = (Application.Current as App).Content;

            // Create a timer for this page
            timer = new GameTimer();
            timer.UpdateInterval = TimeSpan.FromTicks(333333);
            timer.Update += OnUpdate;
            timer.Draw += OnDraw;

            TouchPanel.EnabledGestures = GestureType.DoubleTap | GestureType.Flick |
    GestureType.FreeDrag | GestureType.Hold | GestureType.HorizontalDrag |
    GestureType.None | GestureType.Pinch | GestureType.PinchComplete |
    GestureType.Tap | GestureType.VerticalDrag | GestureType.DragComplete;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // Set the sharing mode of the graphics device to turn on XNA rendering
            SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(true);

            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(SharedGraphicsDeviceManager.Current.GraphicsDevice);

            // TODO: use this.content to load your game content here
            spriteFontSegoeUIMono = contentManager.Load<SpriteFont>("Pescadero");
            spriteFontDrawLocation = new Vector2(40, 40);
            //Load StickMan texture
            StickManTexture = contentManager.Load<Texture2D>("StickMan");
            //Create StickMan sprite object
            StickManGameObject = new GameObject(StickManTexture);
            //Position in the middle of the screen
            StickManGameObject.Position = new Vector2(SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Width / 2,
            SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Height / 2);

            // Start the timer
            timer.Start();

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            // Stop the timer
            timer.Stop();

            // Set the sharing mode of the graphics device to turn off XNA rendering
            SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(false);

            base.OnNavigatedFrom(e);
        }

        /// <summary>
        /// Allows the page to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        private void OnUpdate(object sender, GameTimerEventArgs e)
        {
            // TODO: Add your update logic here
          ProcessTouchInput();
          StickManGameObject.Update(e, 
            SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Bounds);
        }

        private void ProcessTouchInput()
        {
          //Obtain raw touch data to perform hit test for selection
          TouchCollection touches = TouchPanel.GetState();
          if ((touches.Count > 0) && (touches[0].State == TouchLocationState.Pressed))
          {
            // map touch to a Point object to hit test
            Microsoft.Xna.Framework.Point touchPoint = new Microsoft.Xna.Framework.Point((int)touches[0].Position.X,
                                         (int)touches[0].Position.Y);

            if (StickManGameObject.BoundingBox.Contains(touchPoint))
            {
              StickManGameObject.Selected = true;
              StickManGameObject.Velocity = Vector2.Zero;
            }
          }
          //Process gestures
          while (TouchPanel.IsGestureAvailable)
          {
            gestureSample = TouchPanel.ReadGesture();
            gestureInfo = gestureSample.GestureType.ToString();
            if (StickManGameObject.Selected)
            {
              switch (gestureSample.GestureType)
              {
                case GestureType.Hold:
                  StickManGameObject.Rotation += MathHelper.PiOver2;
                  break;
                case GestureType.FreeDrag:
                  StickManGameObject.Position += gestureSample.Delta;
                  break;
                case GestureType.Flick:
                  StickManGameObject.Velocity = gestureSample.Delta;
                  break;
                case GestureType.Pinch:
                  Vector2 FirstFingerCurrentPosition = gestureSample.Position;
                  Vector2 SecondFingerCurrentPosition = gestureSample.Position2;
                  Vector2 FirstFingerPreviousPosition = FirstFingerCurrentPosition -
                          gestureSample.Delta;
                  Vector2 SecondFingerPreviousPosition = SecondFingerCurrentPosition -
                          gestureSample.Delta2;
                  //Calculate distance between fingers for the current and
                  //previous finger positions.  Use it as a ration to
                  //scale object.  Can have positive and negative scale.
                  float CurentPositionFingerDistance = Vector2.Distance(
                    FirstFingerCurrentPosition, SecondFingerCurrentPosition);
                  float PreviousPositionFingerDistance = Vector2.Distance(
                    FirstFingerPreviousPosition, SecondFingerPreviousPosition);

                  float zoomDelta = (CurentPositionFingerDistance -
                                     PreviousPositionFingerDistance) * .03f;
                  StickManGameObject.Scale += zoomDelta;
                  break;
              }
            }
            //StickManGameObject.Selected = false;
          }

          if (gestureSample.Position2 != Vector2.Zero)
          {
            Debug.WriteLine("gesture Type:      " + gestureSample.GestureType.ToString());
            Debug.WriteLine("gesture Timestamp: " + gestureSample.Timestamp.ToString());
            Debug.WriteLine("gesture Position:  " + gestureSample.Position.ToString());
            Debug.WriteLine("gesture Position2: " + gestureSample.Position2.ToString());
            Debug.WriteLine("gesture Delta:     " + gestureSample.Delta.ToString());
            Debug.WriteLine("gesture Delta2:    " + gestureSample.Delta2.ToString());
          }

          //Reset if user is no longer interacting with StickMan
          //
          if (touches.Count == 0)
          {
            StickManGameObject.Selected = false;
          }
        }
        /// <summary>
        /// Allows the page to draw itself.
        /// </summary>
        private void OnDraw(object sender, GameTimerEventArgs e)
        {
            SharedGraphicsDeviceManager.Current.GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            // Draw gesture info
            string output = "Last Gesture: " + gestureInfo;
            // Draw the string
            spriteBatch.DrawString(spriteFontSegoeUIMono, output, spriteFontDrawLocation,
              Color.LightGreen, 0, Vector2.Zero, 1.0f, SpriteEffects.None, 0.5f);
            //Draw the stickman
            StickManGameObject.Draw(spriteBatch);
            spriteBatch.End();
        }
    }
}