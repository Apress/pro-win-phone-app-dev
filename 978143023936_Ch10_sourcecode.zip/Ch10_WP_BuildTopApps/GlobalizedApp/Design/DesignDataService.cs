﻿using System;
using GlobalizedApp.Model;
using System.Collections.Generic;

namespace GlobalizedApp.Design
{
  public class DesignDataService : IDataService
  {
    public void GetData(Action<DataItem, Exception> callback)
    {
      // Use this to create design time data

      var item = new DataItem("Welcome to My Globalized App.");
      callback(item, null);
    }

    public void GetCultureOptions(Action<List<string>, Exception> callback)
    {
      List<string> cultureList = new List<string>(){
        "zh-CN", "zh-TW", "cs-CZ", "da-DK","nl-NL","en-GB","en-US","fi-FI",
        "fr-FR","de-DE","el-GR","hu-HU","it-IT", "ja-JP","ko-KR","nb-NO",
        "pl-PL","pt-BR","pt-PT","ru-RU","es-ES","sv-SE"
      };
      callback(cultureList, null);
    }

    public void SaveCultureSetting(string cultureCode)
    {
    }

    public string LoadCultureSetting()
    {
      return "en-US";
    }
  }
}