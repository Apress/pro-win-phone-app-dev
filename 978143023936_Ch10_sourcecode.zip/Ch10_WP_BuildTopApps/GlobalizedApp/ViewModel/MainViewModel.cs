﻿using GalaSoft.MvvmLight;
using GlobalizedApp.Model;
using System.Collections.Generic;
using System;
using System.Globalization;
using System.Threading;

namespace GlobalizedApp.ViewModel
{
  public class MainViewModel : ViewModelBase
  {
    private readonly IDataService _dataService;
    private CultureInfo cultureInfo;

    public const string ApplicationTitlePropertyName = "ApplicationTitle";
    private string _appTitle = "CHAPTER TEN";
    public string ApplicationTitle
    {
      get
      {
        return _appTitle;
      }

      set
      {
        if (_appTitle == value)
        {
          return;
        }

        _appTitle = value;
        RaisePropertyChanged(ApplicationTitlePropertyName);
      }
    }

    public const string PageNamePropertyName = "PageName";
    private string _pageName = "globalization";
    public string PageName
    {
      get
      {
        return _pageName;
      }

      set
      {
        if (_pageName == value)
        {
          return;
        }

        _pageName = value;
        RaisePropertyChanged(PageNamePropertyName);
      }
    }

    #region Culture Info Properties
    public const string CurrentCultureCodePropertyName = "CurrentCultureCode";
    private string _currentCultureCode = "en-US";
    public string CurrentCultureCode
    {
      get
      {
        return _currentCultureCode;
      }

      set
      {
        if (_currentCultureCode == value)
        {
          return;
        }

        _currentCultureCode = value;
        _dataService.SaveCultureSetting(_currentCultureCode);
        RaisePropertyChanged(CurrentCultureCodePropertyName);
        ShowCultureChangeMessage = true;
        //Update the current thread's culture
        cultureInfo = new CultureInfo(_currentCultureCode);
        Thread.CurrentThread.CurrentCulture = cultureInfo;
        Thread.CurrentThread.CurrentUICulture = cultureInfo;
      }
    }
    
    public const string CultureCodesPropertyName = "CultureCodes";
    private List<string> _cultureCodes = null;
    public List<string> CultureCodes
    {
      get
      {
        return _cultureCodes;
      }

      set
      {
        if (_cultureCodes == value)
        {
          return;
        }

        _cultureCodes = value;
        _cultureCodes.Sort();
        RaisePropertyChanged(CultureCodesPropertyName);
      }
    }

    public const string ShowCultureChangeMessagePropertyName = "ShowCultureChangeMessage";
    private bool _showCultureChangeMessage = false;
    public bool ShowCultureChangeMessage
    {
      get
      {
        return _showCultureChangeMessage;
      }

      set
      {
        if (_showCultureChangeMessage == value)
        {
          return;
        }

        _showCultureChangeMessage = value;
        RaisePropertyChanged(ShowCultureChangeMessagePropertyName);
      }
    }
    #endregion

    #region Fake Properties
    public const string WelcomeTitlePropertyName = "WelcomeTitle";
    private string _welcomeTitle = string.Empty;
    public string WelcomeTitle
    {
      get
      {
        return _welcomeTitle;
      }

      set
      {
        if (_welcomeTitle == value)
        {
          return;
        }

        _welcomeTitle = value;
        RaisePropertyChanged(WelcomeTitlePropertyName);
      }
    }

    public const string PurchaseDatePropertyName = "PurchaseDate";
    private DateTime _purchaseDate = DateTime.Now;
    public DateTime PurchaseDate
    {
      get
      {

        return _purchaseDate;
      }

      set
      {
        if (_purchaseDate == value)
        {
          return;
        }

        _purchaseDate = value;
        RaisePropertyChanged(PurchaseDatePropertyName);
      }
    }

    public const string PurchaseAmountPropertyName = "PurchaseAmount";
    private Double _purchaseAmount = 100.0;
    public  Double PurchaseAmount
    {
      get
      {
        return _purchaseAmount;
      }

      set
      {
        if (_purchaseAmount == value)
        {
          return;
        }

        _purchaseAmount = value;
        RaisePropertyChanged(PurchaseAmountPropertyName);
      }
    }

    public const string ShippingDatePropertyName = "ShippingDate";
    private DateTime _shippingDate = DateTime.Now + TimeSpan.FromDays(30);
    public DateTime ShippingDate
    {
      get
      {
        return _shippingDate;
      }

      set
      {
        if (_shippingDate == value)
        {
          return;
        }

        _shippingDate = value;
        RaisePropertyChanged(ShippingDatePropertyName);
      }
    }
    #endregion
    /// <summary>
    /// Initializes a new instance of the MainViewModel class.
    /// </summary>
    public MainViewModel(IDataService dataService)
    {
      _dataService = dataService;

      if (!this.IsInDesignMode)
      {
        if (_dataService.LoadCultureSetting() != null)
        {
          cultureInfo = new CultureInfo(_dataService.LoadCultureSetting());
          Thread.CurrentThread.CurrentCulture = cultureInfo;
          Thread.CurrentThread.CurrentUICulture = cultureInfo;
        }
        else
        {
          cultureInfo = Thread.CurrentThread.CurrentCulture;
        }
        CurrentCultureCode = cultureInfo.Name;
      }

      _dataService.GetData(
          (item, error) =>
          {
            if (error != null)
            {
              // Report error here
              return;
            }

            WelcomeTitle = item.Title;
          });

      _dataService.GetCultureOptions(
        (cultureList, error) =>
        {
          if (error != null)
          {
            //report error
            return;
          }
          CultureCodes = cultureList;
        });
      //Reset flag to correct start state
      //now that the culture has been configured
      //either via the setting or curent thread value
      ShowCultureChangeMessage = false;
    }
  }
}