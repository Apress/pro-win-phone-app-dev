﻿using Microsoft.Phone.Controls;

namespace GlobalizedApp.View
{
  /// <summary>
  /// Description for Settings.
  /// </summary>
  public partial class Settings : PhoneApplicationPage
  {
    /// <summary>
    /// Initializes a new instance of the Settings class.
    /// </summary>
    public Settings()
    {
      InitializeComponent();
    }
  }
}