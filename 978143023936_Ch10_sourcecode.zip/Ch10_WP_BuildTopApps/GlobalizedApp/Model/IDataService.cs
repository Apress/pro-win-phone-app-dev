﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GlobalizedApp.Model
{
  public interface IDataService
  {
    void GetData(Action<DataItem, Exception> callback);

    void GetCultureOptions(Action<List<string>, Exception> callback);

    void SaveCultureSetting(string cultureCode);

    string LoadCultureSetting();
  }
}
