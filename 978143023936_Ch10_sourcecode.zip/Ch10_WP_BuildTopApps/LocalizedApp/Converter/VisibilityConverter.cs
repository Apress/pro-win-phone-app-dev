﻿using System;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using Microsoft.Phone.Controls;
using System.Windows;

namespace LocalizedApp.Converters
{
  public class VisibilityConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter,
      System.Globalization.CultureInfo culture)
    {
      try
      {
        if ((targetType == typeof(Visibility)) &&
            (value is bool))
        {
          Visibility visibility = Visibility.Visible;
          if ((bool)value == false)
          {
            visibility = Visibility.Collapsed;
          }
          return visibility;
        }
        else
          return value;
      }
      catch (Exception err)
      {
        System.Diagnostics.Debug.WriteLine(err.Message);
        return Visibility.Visible; ;
      }
    }

    public object ConvertBack(object value, Type targetType, object parameter,
      System.Globalization.CultureInfo culture)
    {
      try
      {
        if ((targetType == typeof(bool)) &&
            (value is Visibility))
        {
          bool showMessage = true;
          if ((Visibility)value == Visibility.Collapsed)
          {
            showMessage = false;
          }
          return showMessage;
        }
        else
          return value;
      }
      catch (Exception err)
      {
        System.Diagnostics.Debug.WriteLine(err.Message);
        return Visibility.Visible; ;
      }
    }
  }
}
