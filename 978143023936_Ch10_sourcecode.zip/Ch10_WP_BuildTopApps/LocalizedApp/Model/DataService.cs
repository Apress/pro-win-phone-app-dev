﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;

namespace LocalizedApp.Model
{
  public class DataService : IDataService
  {
    IsolatedStorageSettings settings;

    public DataService()
    {
      settings = IsolatedStorageSettings.ApplicationSettings;
    }

    public void GetData(Action<DataItem, Exception> callback)
    {
      // Use this to connect to the actual data service

      var item = new DataItem("Welcome to My Localized App.");
      callback(item, null);
    }

    public void GetCultureOptions(Action<List<string>, Exception> callback)
    {
      List<string> cultureList = new List<string>(){
        "cs-CZ", "da-DK","nl-NL","en-GB","en-US","fi-FI",
        "fr-FR","de-DE","el-GR","hu-HU","it-IT", "ja-JP","ko-KR","nb-NO",
        "pl-PL","pt-BR","pt-PT","ru-RU","es-ES","sv-SE","zh-CN", "zh-TW"
      };
      callback(cultureList, null);
    }

    public void SaveCultureSetting(string cultureCode)
    {
      settings["cultureCode"] = cultureCode;
    }

    public string LoadCultureSetting()
    {
      string cultureCode = string.Empty;
      settings.TryGetValue<string>("cultureCode", out cultureCode);
      return cultureCode;
    }
  }
}