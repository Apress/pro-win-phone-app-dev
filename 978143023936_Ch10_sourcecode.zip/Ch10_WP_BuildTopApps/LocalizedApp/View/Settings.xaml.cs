﻿using Microsoft.Phone.Controls;

namespace LocalizedApp.View
{
  /// <summary>
  /// Description for Settings.
  /// </summary>
  public partial class Settings : PhoneApplicationPage
  {
    /// <summary>
    /// Initializes a new instance of the Settings class.
    /// </summary>
    public Settings()
    {
      InitializeComponent();
    }
  }
}