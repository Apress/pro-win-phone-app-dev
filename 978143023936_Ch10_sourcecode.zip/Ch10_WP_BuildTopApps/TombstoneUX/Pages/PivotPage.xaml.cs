﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace TombstoneUX.Pages
{
  public partial class PivotPage : PhoneApplicationPage
  {
    public PivotPage()
    {
      InitializeComponent();
      
    }

    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      this.State["Pano"] = Pivot1.SelectedIndex;
      base.OnNavigatedFrom(e);
    }

    protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (this.State.Keys.Contains("Pano"))
        Pivot1.SelectedIndex = (int)this.State["Pano"];
      base.OnNavigatedTo(e);
    }
  }
}