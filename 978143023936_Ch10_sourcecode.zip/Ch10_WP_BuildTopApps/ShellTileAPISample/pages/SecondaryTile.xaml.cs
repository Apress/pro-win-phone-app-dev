﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace ShellTileAPISample.pages
{
  public partial class SecondaryTile : PhoneApplicationPage
  {
    public SecondaryTile()
    {
      InitializeComponent();
    }

    protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);

      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));

      checkBoxDisplaySecondaryTile.IsChecked = (SecondaryTile != null);

      if (NavigationContext.QueryString.ContainsKey("TileKeyData"))
        DeepLinkDataText.Text = this.NavigationContext.QueryString["TileKeyData"];
    }

    private void checkBoxDisplaySecondaryTile_Unchecked(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));

      if (SecondaryTile != null)
      {
        SecondaryTile.Delete();
      }

    }

    private void checkBoxDisplaySecondaryTile_Checked(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));
      if (SecondaryTile == null)
      {
        StandardTileData UpdatedTileData = new StandardTileData
        {
          BackgroundImage = new Uri("/images/BackgroundColor1.jpg", UriKind.Relative),
          Title = "Secondary Tile",
          Count = 33,
          BackTitle = "Back of Tile",
          BackContent = "Welcome to the back of the Tile",
          BackBackgroundImage = new Uri("/images/BackgroundColor2.jpg", UriKind.Relative)
        };
        ShellTile.Create(
          new Uri("/pages/SecondaryTile.xaml?TileKeyData=DataFromTile", UriKind.Relative), UpdatedTileData);
      }

    }

    private void buttonSetTitle_Click(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));

      if (SecondaryTile != null)
      {
        StandardTileData UpdatedTileData = new StandardTileData
        {
          Title = textBoxTitle.Text
        };

        SecondaryTile.Update(UpdatedTileData);
      }

    }

    private void buttonSetBackgroundImage_Click(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));

      if (SecondaryTile != null)
      {
        StandardTileData UpdatedTileData = new StandardTileData
        {
          BackgroundImage = new Uri(textBoxBackgroundImage.Text, UriKind.Relative)
        };

        SecondaryTile.Update(UpdatedTileData);
      }
    }

    private void buttonSetCount_Click(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));
      if (SecondaryTile != null)
      {
        int newCount = 0;
        if (textBoxCount.Text != "")
        {
          newCount = int.Parse(textBoxCount.Text);
        }

        StandardTileData UpdatedTileData = new StandardTileData
        {
          Count = newCount
        };

        SecondaryTile.Update(UpdatedTileData);
      }
    }

    private void buttonSetBackTitle_Click(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));
      if (SecondaryTile != null)
      {
        StandardTileData UpdatedTileData = new StandardTileData
        {
          BackTitle = textBoxBackTitle.Text
        };
        SecondaryTile.Update(UpdatedTileData);
      }
    }

    private void buttonSetBackContent_Click(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));
      if (SecondaryTile != null)
      {
        StandardTileData UpdatedTileData = new StandardTileData
        {
          BackContent = textBoxBackContent.Text
        };

        SecondaryTile.Update(UpdatedTileData);
      }
    }

    private void buttonSetBackBackgroundImage_Click(object sender, RoutedEventArgs e)
    {
      ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(
        x => x.NavigationUri.ToString().Contains("TileKeyData=FromTile"));
      if (SecondaryTile != null)
      {
        StandardTileData UpdatedTileData = new StandardTileData
        {
          BackBackgroundImage = new Uri(textBoxBackBackgroundImage.Text, UriKind.Relative)
        };

        SecondaryTile.Update(UpdatedTileData);
      }

    }
  }
}