﻿using System;
using System.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace ShellTileAPISample.pages
{
  public partial class AppTile : PhoneApplicationPage
  {
    public AppTile()
    {
      InitializeComponent();
    }

    private void ConfigureAppBarButton_Click(object sender, EventArgs e)
    {
      ShellTile ApplicationTile = ShellTile.ActiveTiles.First();

      int newCount = 0;
      if (textBoxCount.Text != "")
      {
        newCount = Convert.ToInt16(textBoxCount.Text);
      }

      StandardTileData UpdatedTileData = new StandardTileData
      {
        Title = textBoxTitle.Text,
        BackgroundImage = new Uri(textBoxBackgroundImage.Text, UriKind.Relative),
        Count = newCount,
        BackTitle = textBoxBackTitle.Text,
        BackBackgroundImage = new Uri(textBoxBackBackgroundImage.Text, UriKind.Relative),
        BackContent = textBoxBackContent.Text
      };
      ApplicationTile.Update(UpdatedTileData);
    }
  }
}