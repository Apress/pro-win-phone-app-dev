﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;
using System.Windows.Threading;
using Microsoft.Xna.Framework;

namespace GyroscopeSensor
{
  public partial class MainPage : PhoneApplicationPage
  {
    Gyroscope gyroscope;
    DispatcherTimer timer;

    Vector3 currentRotationRate = Vector3.Zero;
    Vector3 cumulativeRotation = Vector3.Zero;
    DateTimeOffset lastUpdateTime = DateTimeOffset.MinValue;

    // Constructor
    public MainPage()
    {
      InitializeComponent();
      Application.Current.Host.Settings.EnableFrameRateCounter = false;
      if (!Gyroscope.IsSupported)
      {
        ApplicationBar.IsVisible = false;
      }
      else
      {
        timer = new DispatcherTimer();
        timer.Interval = TimeSpan.FromMilliseconds(60);
        timer.Tick += new EventHandler(timer_Tick);
      }
    }
    void timer_Tick(object sender, EventArgs e)
    {
      if (gyroscope.IsDataValid)
      {
        //draw UI
      }
    }
    void gyroscope_CurrentValueChanged(object sender, SensorReadingEventArgs<GyroscopeReading> e)
    {
      if (lastUpdateTime.Equals(DateTimeOffset.MinValue))
      {
        // If this is the first time CurrentValueChanged was raised,
        // only update the lastUpdateTime variable.
        lastUpdateTime = e.SensorReading.Timestamp;
      }
      else
      {
        currentRotationRate = e.SensorReading.RotationRate;

        TimeSpan timeSinceLastUpdate = e.SensorReading.Timestamp - lastUpdateTime;

        cumulativeRotation += currentRotationRate * (float)(timeSinceLastUpdate.TotalSeconds);
        lastUpdateTime = e.SensorReading.Timestamp;

      }
    }

    private void StopGyro_Click(object sender, EventArgs e)
    {
      if (gyroscope != null && gyroscope.IsDataValid)
      {
        gyroscope.Stop();
        timer.Stop();
      }
    }

    private void StartGyro_Click(object sender, EventArgs e)
    {
      if (gyroscope == null)
      {
        gyroscope = new Gyroscope();
        gyroscope.TimeBetweenUpdates = TimeSpan.FromMilliseconds(20);
        gyroscope.CurrentValueChanged += gyroscope_CurrentValueChanged;
      }
    }
  }
}