﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;
using Microsoft.Xna.Framework;

namespace CompassSensor
{
  public partial class MainPage : PhoneApplicationPage
  {
    Compass compass;
    // Constructor
    public MainPage()
    {
      InitializeComponent();
      if (Compass.IsSupported)
      {
        compass = new Compass();
        compass.TimeBetweenUpdates = TimeSpan.FromMilliseconds(100);
        compass.CurrentValueChanged += compass_CurrentValueChanged;
        compass.Calibrate += compass_Calibrate;
      }
    }

    void compass_Calibrate(object sender, CalibrationEventArgs e)
    {
      Dispatcher.BeginInvoke(() => 
        { calibrationStackPanel.Visibility = Visibility.Visible; });
    }

    void compass_CurrentValueChanged(object sender, SensorReadingEventArgs<CompassReading> e)
    {
      if (compass.IsDataValid)
        ContentPanel.Dispatcher.BeginInvoke(() =>
          {
            XamlMagCompassAngle.Rotation = e.SensorReading.MagneticHeading * -1;
            XamlTrueCompassAngle.Rotation = e.SensorReading.TrueHeading * -1;
            MagHeadingValue.Text = String.Format("{0}°", e.SensorReading.MagneticHeading);
            TrueHeadingValue.Text = String.Format("{0}°", e.SensorReading.TrueHeading);
            HeadingAccuracy.Text = String.Format("Heading Accuracy: {0}°", e.SensorReading.HeadingAccuracy);
            MagnetometerReading.Text =
              String.Format("Magnetometer: {0:0.00} microteslas", e.SensorReading.MagnetometerReading.Length());
            calibrationTextBlock.Text = e.SensorReading.HeadingAccuracy.ToString() + "°";
            if (e.SensorReading.HeadingAccuracy > 10d)
              calibrationTextBlock.Foreground = new SolidColorBrush(Colors.Red);
            else
              calibrationTextBlock.Foreground = new SolidColorBrush(Colors.Green);
          });

    }
    private void StartCompass_Click(object sender, EventArgs e)
    {
      if (compass != null)
        compass.Start();
    }

    private void StopCompass_Click(object sender, EventArgs e)
    {
      if (compass != null)
        compass.Stop();
    }

    protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
    {
      if (calibrationStackPanel.Visibility == Visibility.Visible)
      {
        calibrationStackPanel.Visibility = Visibility.Collapsed;
        e.Cancel = true;
      }
      base.OnBackKeyPress(e);
    }
  }
}