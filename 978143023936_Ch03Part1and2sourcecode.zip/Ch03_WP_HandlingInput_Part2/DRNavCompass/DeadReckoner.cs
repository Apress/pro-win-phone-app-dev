﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Threading;
using Microsoft.Devices.Sensors;

namespace DRNavigationCompass
{
  public class DeadReckoner : IDisposable, INotifyPropertyChanged
  {
    #region private declarations
    Compass _compass;
    DispatcherTimer _fixTimer;
    DispatcherTimer _processTimer;
    //state
    DateTime _dRStartTime;
    DateTime _dRStopTime;
    #endregion

    //This determines if a turn is detected on a per fix basis
    const double BEARING_ACCURACY_LIMIT = 15;

    private ObservableCollection<SensorsFix> _fixReadings { get; set; }

    //Constructor
    public DeadReckoner()
    {
      CreateSensors();
      _fixTimer = new DispatcherTimer();
      FixInterval = new TimeSpan(10000);
      _fixTimer.Interval = FixInterval;
      _fixTimer.Tick += new EventHandler(fixTimer_Tick);

      _processTimer = new DispatcherTimer();
      _processTimer.Interval = new TimeSpan(100000);
      _processTimer.Tick += new EventHandler(processTimer_Tick);

      _fixReadings = new ObservableCollection<SensorsFix>();
      NavigationInstructions = new ObservableCollection<DRNavigationCompassStep>();
    }

    #region Public Properties
    public ObservableCollection<DRNavigationCompassStep> NavigationInstructions { get; set; }

    TimeSpan _fixInterval;
    public TimeSpan FixInterval
    {
      get
      {
        return _fixInterval;
      }
      set
      {
        _fixInterval = value;
        if ((Compass.IsSupported) && (_compass != null))
          _compass.TimeBetweenUpdates = _fixInterval;
        _fixTimer.Interval = _fixInterval;
      }
    }
    #endregion

    void fixTimer_Tick(object sender, EventArgs e)
    {
      _fixReadings.Add(CreateFixHelper(NavigationInstructions.Last().NavStepID));

    }

    #region Processing Fixes
    private bool _processing;

    public bool Processing
    {
      get { return _processing; }
      set
      {
        _processing = value;
        NotifyPropertyChanged("Processing");
      }
    }

    void processTimer_Tick(object sender, EventArgs e)
    {
      Debug.WriteLine("Eval Fixes Tick" + DateTime.Now.Ticks.ToString());
      //Detect new DR fixes
      var unprocessedFixes = from reading in _fixReadings
                             where reading.Processed == false
                             select reading;

      if (unprocessedFixes.Count<SensorsFix>() == 0)
      {
        //No longer collecting data
        _processTimer.Stop();
      }
      else
      { //Process fixes
        //detect when going straight
        //detect when makng a turn
        //detect when coming out of a turn
        double currentBearing;
        double newBearing;
        double bearingDelta;

        DRNavigationCompassStep currentNavStep;
        DRNavigationCompassStep newStep;
        foreach (SensorsFix reading in unprocessedFixes)
        {
          //Always get latest in case a new step was added while processing
          currentNavStep = NavigationInstructions.Last();
          //bearing is changing
          newBearing = reading.CompassReading.TrueHeading;
          currentBearing = currentNavStep.Bearing;
          bearingDelta = currentBearing - newBearing;
          if (Math.Abs(bearingDelta) < BEARING_ACCURACY_LIMIT)
          {
            currentNavStep.Time += reading.TimeSinceLastFix;
          }
          else
            //Adjust  direction based on current state
            switch (currentNavStep.Direction)
            {
              case DRDirection.TurningLeft:
                if (bearingDelta > 0)//still moving left
                  currentNavStep.Bearing = reading.CompassReading.TrueHeading;
                else //stopped turning left
                {
                  //done turning, add a new step to go straight
                  newStep = new DRNavigationCompassStep();
                  newStep.NavStepID = DRNavigationCompassStep.NextStepID;
                  newStep.Bearing = reading.CompassReading.TrueHeading;
                  newStep.Direction = DRDirection.GoingStraight;
                  NavigationInstructions.Add(newStep);
                }
                currentNavStep.Time += reading.TimeSinceLastFix;
                break;
              case DRDirection.TurningRight:
                if (bearingDelta < 0)//still moving right
                  currentNavStep.Bearing = reading.CompassReading.TrueHeading;
                else //stopped turning right
                {
                  //done turning, add a new step to go straight
                  newStep = new DRNavigationCompassStep();
                  newStep.NavStepID = DRNavigationCompassStep.NextStepID;
                  newStep.Bearing = reading.CompassReading.TrueHeading;
                  newStep.Direction = DRDirection.GoingStraight;
                  NavigationInstructions.Add(newStep);
                }
                currentNavStep.Time += reading.TimeSinceLastFix;
                break;
              case DRDirection.GoingStraight:
                newStep = new DRNavigationCompassStep();
                newStep.NavStepID = DRNavigationCompassStep.NextStepID;
                newStep.Bearing = reading.CompassReading.TrueHeading;
                //update direction based on changes
                if (bearingDelta > 0)
                  newStep.Direction = DRDirection.TurningLeft;
                else
                  newStep.Direction = DRDirection.TurningRight;
                NavigationInstructions.Add(newStep);
                currentNavStep.Time += reading.TimeSinceLastFix;
                break;
              case DRDirection.Unknown:
                break;
              default:
                break;
            }
          reading.Processed = true;
        }
      }
    }
    #endregion

    #region Create / Dispose methods
    private void CreateSensors()
    {
      if (Compass.IsSupported)
        _compass = new Compass();
    }

    private SensorsFix CreateInitialFixHelper(int navStepID)
    {
      SensorsFix newSensorFix = new SensorsFix();

      if (Compass.IsSupported)
        newSensorFix.CompassReading = _compass.CurrentValue;

      newSensorFix.NavStepID = navStepID;
      newSensorFix.FixTime = DateTime.Now;
      newSensorFix.TimeSinceLastFix = new TimeSpan(0);
      return newSensorFix;
    }

    private SensorsFix CreateFixHelper(int navStepID)
    {
      SensorsFix newSensorFix = new SensorsFix();
      if (Compass.IsSupported)
      {
        newSensorFix.CompassReading = _compass.CurrentValue;
        Debug.WriteLine("Collect Fix - Compass Course " + _compass.CurrentValue.TrueHeading);
      }
      newSensorFix.NavStepID = navStepID;
      newSensorFix.FixTime = DateTime.Now;
      newSensorFix.TimeSinceLastFix = newSensorFix.FixTime - _fixReadings.Last().FixTime;
      return newSensorFix;
    }

    private DRNavigationCompassStep CreateInitialNavStepHelper()
    {
      DRNavigationCompassStep firstNavStep = new DRNavigationCompassStep();
      firstNavStep.Bearing = _fixReadings.Last().CompassReading.TrueHeading;
      firstNavStep.Direction = DRDirection.GoingStraight;
      firstNavStep.Time = new TimeSpan(0);
      firstNavStep.Speed = 0d;
      firstNavStep.NavStepID = DRNavigationCompassStep.NextStepID;
      firstNavStep.MovementState = DRMovementState.Unknown;
      _fixReadings.Last().Processed = true;
      return firstNavStep;
    }

    private void DisposeSensors()
    {
      if (Compass.IsSupported)
        _compass.Dispose();
    }

    public void Dispose()
    {
      DisposeSensors();
      GC.SuppressFinalize(this);
    }
    #endregion

    #region Start / Stop Methods
    public void StartDR()
    {
      if (!_processTimer.IsEnabled)
      {
        StartSensors();
        //Let sensors spin up for three seconds
        System.Threading.Thread.Sleep(2000);
        //Only initiailze if starting app, not resuming
        if (NavigationInstructions.Count == 0)
          InitializeCollections();
        //Now start timers
        _fixTimer.Start();
        _processTimer.Start();
        _dRStartTime = DateTime.Now;
        Processing = true;
      }
    }

    private void InitializeCollections()
    {
      //Create first fix
      _fixReadings.Add(CreateInitialFixHelper(1));

      //Create first navagation step
      NavigationInstructions.Add(CreateInitialNavStepHelper());
    }

    public void StopDR()
    {
      if (_processTimer.IsEnabled)
      {
        _fixTimer.Stop();
        _dRStopTime = DateTime.Now;
        StopSensors();
        Processing = false;
      }
    }

    void StartSensors()
    {
      if (Compass.IsSupported)
        _compass.Start();
    }

    void StopSensors()
    {
      if (Compass.IsSupported)
        _compass.Stop();
    }
    #endregion

    #region INotifyPropertyChanged
    public event PropertyChangedEventHandler PropertyChanged;

    private void NotifyPropertyChanged(String propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }
    #endregion


    public void ClearData()
    {
      NavigationInstructions.Clear();
      _fixReadings.Clear();
    }
  }

  public class SensorsFix
  {
    public int NavStepID;
    public AccelerometerReading AccelerometerReading;
    public CompassReading CompassReading;
    public GyroscopeReading GyroScopeReading;
    public MotionReading MotionReading;
    public DateTime FixTime;
    public TimeSpan TimeSinceLastFix;
    public bool Processed;
  }

  public class DRNavigationCompassStep
  {
    //Link each reading to a Nav Step
    //This could allow additional post-processing
    //to make sure that the ultimate direction of turns
    //is correct by doing a full run through all steps
    //at the end of the captures
    static private int _nextStepID;
    static public int NextStepID
    {
      get
      {
        _nextStepID++;
        return _nextStepID;
      }
      set { _nextStepID = value; }
    }

    public int NavStepID { get; set; }
    public TimeSpan Time { get; set; }
    //if Direction is straight, maintain bearing
    //in a turn this is the new bearing to turn to
    public double Bearing { get; set; }
    public double Speed { get; set; }
    public DRDirection Direction { get; set; }
    public DRMovementState MovementState { get; set; }
  }

  public enum DRDirection
  {
    Unknown,
    TurningLeft,
    TurningRight,
    GoingStraight
  }

  public enum DRMovementState
  {
    Unknown,
    Stopped,
    Moving
  }
}
