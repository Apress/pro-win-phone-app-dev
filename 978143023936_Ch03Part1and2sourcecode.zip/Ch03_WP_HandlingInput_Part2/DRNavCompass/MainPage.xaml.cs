﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

namespace DRNavigationCompass
{
  public partial class MainPage : PhoneApplicationPage
  {
    DeadReckoner deadReconner;
    // Constructor
    public MainPage()
    {
      InitializeComponent();
      this.Loaded += new RoutedEventHandler(MainPage_Loaded);
    }

    void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
      deadReconner = (DeadReckoner)LayoutRoot.DataContext;
    }

    private void StartCaptureABbtn_Click(object sender, EventArgs e)
    {
      progressBar.Visibility = Visibility.Visible;
      NavInstructionsLB.Visibility = Visibility.Collapsed;
      deadReconner.StartDR();
    }

    private void StopRecordingABbtn_Click(object sender, EventArgs e)
    {
      deadReconner.StopDR();
      progressBar.Visibility = Visibility.Collapsed;
      InstructionsText.Visibility = Visibility.Collapsed;
      NavInstructionsLB.Visibility = Visibility.Visible;
    }

    private void ClearDataABmenu_Click(object sender, EventArgs e)
    {
      if (deadReconner.Processing == true)
        if (MessageBox.Show("Stop Processing?", "Processing", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
        {
          deadReconner.StopDR();
          progressBar.Visibility = Visibility.Collapsed;
          NavInstructionsLB.Visibility = Visibility.Visible;
        }
      deadReconner.ClearData();
      InstructionsText.Visibility = Visibility.Visible;
    }

    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      //Clean up when navigating away from page
      deadReconner.StopDR();
      deadReconner.Dispose();
      
      base.OnNavigatedFrom(e);
    }
  }
}