﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices;
using Microsoft.Xna.Framework.Media;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;

namespace CameraSensor.pages
{
  public partial class CustomCamera : PhoneApplicationPage
  {
    public PhotoCamera _photoCamera;
    MediaLibrary _mediaLibray;

    ObservableCollection<BitmapImage> ThumbImages;

    public CustomCamera()
    {
      InitializeComponent();
      this.Loaded += new RoutedEventHandler(CustomCamera_Loaded);
    }

void CustomCamera_Loaded(object sender, RoutedEventArgs e)
{
  //Can set to CameraType.FrontFacing if available
  _photoCamera = new PhotoCamera(CameraType.Primary);
  //wire up event handlers
  _photoCamera.AutoFocusCompleted += _photoCamera_AutoFocusCompleted;
  _photoCamera.CaptureCompleted += _photoCamera_CaptureCompleted;
  _photoCamera.CaptureImageAvailable += _photoCamera_CaptureImageAvailable;
  _photoCamera.CaptureStarted += _photoCamera_CaptureStarted;
  _photoCamera.CaptureThumbnailAvailable += _photoCamera_CaptureThumbnailAvailable;
  _photoCamera.Initialized += _photoCamera_Initialized;

  //Wire up camera button
  CameraButtons.ShutterKeyHalfPressed += CameraButtons_ShutterKeyHalfPressed;
  CameraButtons.ShutterKeyPressed += CameraButtons_ShutterKeyPressed;
  CameraButtons.ShutterKeyReleased += CameraButtons_ShutterKeyReleased;

  //Set up view finder
  cameraViewFinder.SetSource(_photoCamera);

  LayoutRoot.Tap += LayoutRoot_Tap;

  //Create MediaLibrary object
  _mediaLibray = new MediaLibrary();

  ThumbImages = new ObservableCollection<BitmapImage>();
  ThumbImageLB.ItemsSource = ThumbImages;
}

    void CameraButtons_ShutterKeyReleased(object sender, EventArgs e)
    {
      _photoCamera.CancelFocus();
    }

    void CameraButtons_ShutterKeyPressed(object sender, EventArgs e)
    {
      try
      {
        _photoCamera.CaptureImage();
      }
      catch (Exception error)
      {
        this.Dispatcher.BeginInvoke(() =>
          {
            cameraStatus.Text = "Camera not ready..."+error.Message;
          });
      }
    }

    void CameraButtons_ShutterKeyHalfPressed(object sender, EventArgs e)
    {
      _photoCamera.Focus();
    }

    void LayoutRoot_Tap(object sender, GestureEventArgs e)
    {
      if (ShowCameraSettings.GetCurrentState() != ClockState.Active) 
        ShowCameraSettings.Begin();
    }

    void _photoCamera_Initialized(object sender, CameraOperationCompletedEventArgs e)
    {
      if (e.Succeeded)
      {
        this.Dispatcher.BeginInvoke(delegate()
        {
          // Write message.
          cameraStatus.Text = "Camera initialized.";

          // Set flash button text.
          FlashBtn.Content = _photoCamera.FlashMode.ToString() + " Flash";

          //Populate Available Resolutions
          PopulateAvailableResolutions();
        });
      }
    }

    private void PopulateAvailableResolutions()
    {
      AvailResolutionsLB.ItemsSource = _photoCamera.AvailableResolutions;
    }

    void _photoCamera_CaptureThumbnailAvailable(object sender, ContentReadyEventArgs e)
    {
      this.Dispatcher.BeginInvoke(() =>
        {
          BitmapImage bitmap = new BitmapImage();
          bitmap.CreateOptions = BitmapCreateOptions.None;
          bitmap.SetSource(e.ImageStream);
          ThumbImages.Add(bitmap);
        });
    }

    void _photoCamera_CaptureStarted(object sender, EventArgs e)
    {
      this.Dispatcher.BeginInvoke(() =>
        {
          cameraStatus.Text = "Photo capture started...";
        });
    }

    void _photoCamera_CaptureImageAvailable(object sender, ContentReadyEventArgs e)
    {
      _mediaLibray.SavePictureToCameraRoll("TestPhoto" + DateTime.Today.Date.ToString(), e.ImageStream);
      this.Dispatcher.BeginInvoke(() =>
      {
        cameraStatus.Text = "Image saved to camera roll...";
      });
    }

    void _photoCamera_CaptureCompleted(object sender, CameraOperationCompletedEventArgs e)
    {
      this.Dispatcher.BeginInvoke(() =>
        {
          if (e.Succeeded)
            cameraStatus.Text = "Photo capture completed...";
            
          else
            cameraStatus.Text = "Photo capture not successful...";
        });
    }

    void _photoCamera_AutoFocusCompleted(object sender, CameraOperationCompletedEventArgs e)
    {
      this.Dispatcher.BeginInvoke(() =>
      {
        if (e.Succeeded)
          cameraStatus.Text = "Auto focus completed...";

        else
          cameraStatus.Text = "Auto focus not successful...";
      });
    }

    private void FlashBtn_Click(object sender, RoutedEventArgs e)
    {
      if ((_photoCamera.FlashMode == FlashMode.Off) &&
        (_photoCamera.IsFlashModeSupported(FlashMode.On)))
      {
        _photoCamera.FlashMode = FlashMode.On;
        FlashBtn.Content = "Flash Mode: On";
        return;
      }
      if (_photoCamera.FlashMode == FlashMode.On)
        if (_photoCamera.IsFlashModeSupported(FlashMode.RedEyeReduction))
        {
          _photoCamera.FlashMode = FlashMode.RedEyeReduction;
          FlashBtn.Content = "Flash Mode: Redude Red Eye";
          return;
        }
        else
          if (_photoCamera.IsFlashModeSupported(FlashMode.Auto))
          {
            _photoCamera.FlashMode = FlashMode.Auto;
            FlashBtn.Content = "Flash Mode: Auto";
            return;
          }

      if ((_photoCamera.FlashMode == FlashMode.Auto) &&
      (_photoCamera.IsFlashModeSupported(FlashMode.Off)))
      {
        _photoCamera.FlashMode = FlashMode.Off;
        FlashBtn.Content = "Flash Mode: Off";
        return;
      }
    }

    private void ShutterBtn_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        _photoCamera.CaptureImage();
      }
      catch (Exception error)
      {
        this.Dispatcher.BeginInvoke(delegate()
        {
          cameraStatus.Text = error.Message;
        });
      }
    }

    private void FocusBtn_Click(object sender, RoutedEventArgs e)
    {
      if (_photoCamera.IsFocusSupported == true)
      {
        //Focus when a capture is not in progress.
        try
        {
          _photoCamera.Focus();
        }
        catch (Exception error)
        {
          // Cannot focus when a capture is in progress.
          this.Dispatcher.BeginInvoke(() =>
          {
            cameraStatus.Text = error.Message;
          });
        }
      }
    }

    private void AvailResolutionsLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      _photoCamera.Resolution = (Size)e.AddedItems[0];
      cameraStatus.Text = "Camera Resolution = " + _photoCamera.Resolution;
    }

  }
}