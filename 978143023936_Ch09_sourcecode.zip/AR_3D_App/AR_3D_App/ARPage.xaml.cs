﻿using System;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Devices;
using Microsoft.Devices.Sensors;
using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace AR_3D_App
{
  public partial class ARPage : PhoneApplicationPage
  {
    #region fields
    ContentManager contentManager;
    GameTimer timer;
    SpriteBatch spriteBatch;
    Model flyingSaucerModel;
    Motion motionSensor;

    Matrix deviceRotation;
    Quaternion deviceQuaternion;
    Vector3 position = new Vector3(0f, 0f, 3f);
    Matrix world, view, projection;

    PhotoCamera cameraSensor;
    UIElementRenderer cameraOutputRenderer;
    #endregion
    public ARPage()
    {
      InitializeComponent();


      // Get the content manager from the application
      contentManager = (Application.Current as App).Content;

      // Create a timer for this page
      timer = new GameTimer();
      timer.UpdateInterval = TimeSpan.FromTicks(333333);
      timer.Update += OnUpdate;
      timer.Draw += OnDraw;
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {

      // Set the sharing mode of the graphics device to turn on XNA rendering
      SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(true);

      //Set up the Camera Sensor for AR
      cameraSensor = new PhotoCamera();
      cameraVideoBrush.SetSource(cameraSensor);
      //Set width and height for landscape
      cameraOutputRenderer = new UIElementRenderer(LayoutRoot,
        SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Width,
        SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Height);


      // Create a new SpriteBatch, which can be used to draw textures.
      spriteBatch = new SpriteBatch(SharedGraphicsDeviceManager.Current.GraphicsDevice);
      flyingSaucerModel = contentManager.Load<Model>("spaceship");
      // TODO: use this.content to load your game content here

      world = Matrix.Identity;
      projection = Matrix.CreatePerspectiveFieldOfView((float)(MathHelper.ToRadians(55f)), 
        SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.AspectRatio, 0.1f, 10000f);
      view = Matrix.CreateLookAt(new Vector3(0f, 0f, 4f), Vector3.Zero, Vector3.Up);

      if (motionSensor == null && Motion.IsSupported)
      {
        motionSensor = new Motion();
        motionSensor.Start();
      }
      // Start the timer
      timer.Start();

      base.OnNavigatedTo(e);
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
      // Stop the timer
      timer.Stop();
      // Set the sharing mode of the graphics device to turn off XNA rendering
      SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(false);
      //Dispose of Camera
      cameraSensor.Dispose();

      base.OnNavigatedFrom(e);
    }

    private void OnUpdate(object sender, GameTimerEventArgs e)
    {

      if (Motion.IsSupported && motionSensor.IsDataValid)
      {
        deviceRotation = motionSensor.CurrentValue.Attitude.RotationMatrix;
        Quaternion q = motionSensor.CurrentValue.Attitude.Quaternion;
        deviceQuaternion = new Quaternion(q.X, q.Z, q.Y, q.W);
      }
    }

    private void OnDraw(object sender, GameTimerEventArgs e)
    {
      SharedGraphicsDeviceManager.Current.GraphicsDevice.Clear(
        Microsoft.Xna.Framework.Color.Black);

      Vector3 PhoneForward = 
        -new Vector3(deviceRotation.M13, deviceRotation.M23, deviceRotation.M33);
      Vector3 cameraPosition = new Vector3(0, 0, 0);

      // Phone up is always X (in device coordinates)
      // Get it in earth coordinates:
      Vector3 PhoneUp = 
        new Vector3(deviceRotation.M11, deviceRotation.M21, deviceRotation.M31);

      // Change of coordinates for XNA:
      Vector3 cameraFront = new Vector3(PhoneForward.X, PhoneForward.Z, -PhoneForward.Y);
      Vector3 cameraUp = new Vector3(PhoneUp.X, PhoneUp.Z, -PhoneUp.Y);

      Matrix viewMatrix = 
        Matrix.CreateLookAt(cameraPosition, cameraPosition + cameraFront, cameraUp);

      Matrix worldMatatrix = 
        Matrix.CreateWorld(Vector3.Zero, Vector3.Backward, Vector3.Up);
      worldMatatrix *= Matrix.CreateTranslation(position);

      Matrix projMatrix = 
        Matrix.CreatePerspectiveFieldOfView((float)(MathHelper.PiOver4 / 1.5f), 
        SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.AspectRatio,
        0.1f, 10000f);
      
      //Render the Camera Output
      cameraOutputRenderer.Render();
      spriteBatch.Begin();
      spriteBatch.Draw(cameraOutputRenderer.Texture, Vector2.Zero, Color.White);
      spriteBatch.End();

      Matrix[] transforms = new Matrix[flyingSaucerModel.Bones.Count];
      flyingSaucerModel.CopyAbsoluteBoneTransformsTo(transforms);

      foreach (ModelMesh mesh in flyingSaucerModel.Meshes)
      {
        foreach (BasicEffect effect in mesh.Effects)
        {
          effect.EnableDefaultLighting();
          effect.View = viewMatrix;
          effect.World = worldMatatrix;
          effect.Projection = projMatrix;
        }
        mesh.Draw();
      }
    }
  }
}