using System;
using Microsoft.Devices;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace AlienShooterSL.GameObjects
{
  class GameStatusBoard
  {
    UIElementRenderer HUDRenderer;
    private SoundEffect _alienExplosionSoundEffect;
    private SoundEffect _heroShipDamageSoundEffect;
    private VibrateController _vibrateController = VibrateController.Default;
    private TimeSpan _vibrateTimeSpan = TimeSpan.FromMilliseconds(400);
    //Status Board related fields
    private bool _displayMessage;
    private TextBlock _scoreText;
    private TextBlock _messageText;
    private TextBlock _livesText;

    public GameStatusBoard(UIElement element, int width, int height)
    {
      HUDRenderer = new UIElementRenderer(element, width, height);
      _scoreText = ((Grid)element).FindName("ScoreValueText") as TextBlock;
      _messageText = ((Grid)element).FindName("MessageText") as TextBlock;
      _livesText = ((Grid)element).FindName("LivesValueText") as TextBlock;
      Score = 0;
      Lives = 3;
    }

    #region Properties
    private int _score;
    public int Score
    {
      get { return _score; }
      set
      {
        _score = value;
        _scoreText.Text = Convert.ToString(_score);
        if (_alienExplosionSoundEffect != null)
          _alienExplosionSoundEffect.Play();
      }
    }

    private int _lives;
    public int Lives
    {
      get { return _lives; }
      set
      {
        _lives = value;
        if (_heroShipDamageSoundEffect != null)
        {
          _heroShipDamageSoundEffect.Play();
          _vibrateController.Start(_vibrateTimeSpan);
        }
      }
    }

    public bool GameOver { get; set; }
    #endregion

    #region Methods
    public void LoadContent(ContentManager content)
    {
      _alienExplosionSoundEffect =
        content.Load<SoundEffect>("SoundEffects/Explosion");
      _heroShipDamageSoundEffect =
        content.Load<SoundEffect>("SoundEffects/HeroShipDamage");
    }

    public void Update(GameTimerEventArgs GameTime)
    {
      switch (Score)
      {
        case 50: _displayMessage = true;
          _messageText.Text = "Nice Start!";
          break;
        case 60: _displayMessage = false;
          break;
        case 100: _displayMessage = true;
          _messageText.Text = "Keep It Up!";
          break;
        case 120: _displayMessage = false;
          break;
        default: break;
      }

      switch (Lives)
      {
        case 3: _livesText.Foreground = new SolidColorBrush(Colors.Green);
          _livesText.Text = "3";
          break;
        case 2: _livesText.Foreground = new SolidColorBrush(Colors.Yellow);
          _displayMessage = true;
          _messageText.Text = "Waring!";
          _livesText.Text = "2";
          break;
        case 1: _livesText.Foreground = new SolidColorBrush(Colors.Red);
          _displayMessage = true;
          _messageText.Text = "Danger!";
          _livesText.Text = "1";
          break;
        case 0: _livesText.Foreground = new SolidColorBrush(Colors.Red);
          _displayMessage = true;
          _messageText.Text = "Game Over!";
          _livesText.Text = "0";
          GameOver = true;
          break;
      }
    }

    public void Draw(GameTimerEventArgs gameTime, SpriteBatch spriteBatch)
    {
      HUDRenderer.Render();
      spriteBatch.Draw(HUDRenderer.Texture,
        Vector2.Zero, Microsoft.Xna.Framework.Color.White);
    }
    #endregion
  }
}