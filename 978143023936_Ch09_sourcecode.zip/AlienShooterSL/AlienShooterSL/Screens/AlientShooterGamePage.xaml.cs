﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using SpriteSheetRuntime;
using AlienShooterSL.GameObjects;
using XNA=Microsoft.Xna.Framework;
using AlienShooterSL.ParticleSystem;
using AlienShooterSL.GameManagement;
using Microsoft.Xna.Framework.Input;
using System.IO.IsolatedStorage;
using System.IO;
using Microsoft.Xna.Framework.Input.Touch;

namespace AlienShooterSL
{
  public partial class GamePage : PhoneApplicationPage
  {

    #region Fields
    GameTimer timer;
    SpriteBatch spriteBatch;
    ContentManager contentManager;
    SpriteSheet alienShooterSpriteSheet;
    Texture2D backgroundTexture;
    Vector2 backgroundPosition;
    XNA.Rectangle screenRect;

    //Game objects
    GameStatusBoard statusBoard;
    List<AlienGameObject> enemies;
    int maxEnemies = 5;
    UserGameObject heroShip;
    int maxMissiles = 3;
    const string AlienShooterStateFileName = "AlienShooter.dat";
    //Add Explosions and Smoke Game Components to AlienShooter
    ExplosionSmokeParticleSystem explosionSmokeParticleSystem;
    ExplosionParticleSystem explosionParticleSystem;
    SmokePlumeParticleSystem smokePlumeParticleSystem;
     //helper object to collect input
    InputState input;
    // Look up inputs for the active player profile.
    //Windows Phone specific (SL+XNA) set to 0
    int playerIndex = 0;
    #endregion

    public GamePage()
    {
      InitializeComponent();

      // Get the content manager from the application
      contentManager = (Application.Current as App).Content;

      // Create a timer for this page
      timer = new GameTimer();
      timer.UpdateInterval = TimeSpan.FromTicks(333333);
      timer.Update += OnUpdate;
      timer.Draw += OnDraw;
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
      // Set the sharing mode of the graphics device to turn on XNA rendering
      SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(true);
      // Start the timer
      timer.Start();
      
      //Load Content
      alienShooterSpriteSheet = contentManager.Load<SpriteSheet>("Sprites/AlienShooterSpriteSheet");

      backgroundTexture = contentManager.Load<Texture2D>("Textures/background");
      backgroundPosition = new Vector2(0, 34);

      //Get a pointer to the entire screen Rectangle 
      screenRect = SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Bounds;

      // Create a new SpriteBatch, which can be used to draw textures.
      spriteBatch = new SpriteBatch(SharedGraphicsDeviceManager.Current.GraphicsDevice);

      //Add Explosions and Smoke Game Components to AlienShooter
      explosionSmokeParticleSystem = new ExplosionSmokeParticleSystem(timer, 2);
      explosionParticleSystem = new ExplosionParticleSystem(timer, 1);
      smokePlumeParticleSystem = new SmokePlumeParticleSystem(timer, 8);
      
      //Initialize input helper
      input = new InputState();
      TouchPanel.EnabledGestures = GestureType.None;

      //Load game state if user selects resume
      if (NavigationContext.QueryString["start"] == "resume")
        LoadAlienShooterState("resume");
      else
        LoadAlienShooterState("new");


      base.OnNavigatedTo(e);
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
      // Stop the timer
      timer.Stop();
      SaveAlienShooterState();

      // Set the sharing mode of the graphics device to turn off XNA rendering
      SharedGraphicsDeviceManager.Current.GraphicsDevice.SetSharingMode(false);

      base.OnNavigatedFrom(e);
    }

    /// <summary>
    /// Allows the page to run logic such as updating the world,
    /// checking for collisions, gathering input, and playing audio.
    /// </summary>
    private void OnUpdate(object sender, GameTimerEventArgs e)
    {
      // TODO: Add your update logic here
      input.Update();
      HandleInput(input);

      if (!statusBoard.GameOver)
      {
        CheckForCollisions();

        heroShip.Update(e);
        statusBoard.Update(e);

        for (int i = 0; i < maxEnemies; i++)
        {
          enemies[i].Update(e);
        }
      }

    }

    private void CheckForCollisions()
    {
      //Checking for two major collisions
      //1 - Has an in flight missile intersected an alien spaceship - score 5 pts
      for (int i = 0; i < heroShip.MaxNumberofMissiles; i++)
        if (heroShip.Missiles[i].Alive)
          for (int j = 0; j < maxEnemies; j++)
            if ((enemies[j].Alive) &&
                (enemies[j].BoundingRect.Intersects(heroShip.Missiles[i].BoundingRect)))
            {
              statusBoard.Score += 5;
              //Display Explosion
              explosionSmokeParticleSystem.AddParticles(enemies[j].Position);
              explosionParticleSystem.AddParticles(enemies[j].Position);
              enemies[j].ResetGameObject();
              heroShip.Missiles[i].ResetGameObject();
            }
      //2 - Has an alien spaceship intersected the hero ship - deduct a life
      for (int j = 0; j < maxEnemies; j++)
        if ((enemies[j].Alive) && (enemies[j].Position.Y > 600) &&
            (enemies[j].BoundingRect.Intersects(heroShip.BoundingRect)))
        {
          statusBoard.Lives -= 1;
          smokePlumeParticleSystem.AddParticles(heroShip.Position);

          for (int i = 0; i < maxEnemies; i++)
            enemies[i].ResetGameObject();
          for (int i = 0; i < heroShip.MaxNumberofMissiles; i++)
            heroShip.Missiles[i].ResetGameObject();
        }
    }

    /// <summary>
    /// Lets the game respond to player input. Unlike the Update method,
    /// this will only be called when the gameplay screen is active.
    /// </summary>
    public void HandleInput(InputState input)
    {
      if (input == null)
        throw new ArgumentNullException("input not initialized");

      KeyboardState keyboardState = input.CurrentKeyboardStates[playerIndex];
      GamePadState gamePadState = input.CurrentGamePadStates[playerIndex];

      // Otherwise handle input for user controlled objects
      heroShip.HandleInput(input);

    }


    /// <summary>
    /// Allows the page to draw itself.
    /// </summary>
    private void OnDraw(object sender, GameTimerEventArgs e)
    {
      SharedGraphicsDeviceManager.Current.GraphicsDevice.Clear(ClearOptions.Target,
                                         Color.SlateBlue, 0, 0);

      spriteBatch.Begin();
      //Draw Background
      spriteBatch.Draw(backgroundTexture, backgroundPosition, Color.White);
      //Draw Status Board
      statusBoard.Draw(e, spriteBatch);
      //Draw Hero Ship
      heroShip.Draw(e, spriteBatch);
      //Draw enemies
      if (!statusBoard.GameOver)
      {
        for (int i = 0; i < maxEnemies; i++)
        {
          enemies[i].Draw(e, spriteBatch);
        }
      }
      spriteBatch.End();
    }

    //Save state if Back Key Pressed
    protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
    {
      SaveAlienShooterState();
      base.OnBackKeyPress(e);
    }


    #region State Persistence

    public void SaveAlienShooterState()
    {
      //Only save game if not GameOver
      using (IsolatedStorageFile gameStorage =
        IsolatedStorageFile.GetUserStoreForApplication())
      {
        //Overwrite existing saved game state
        if (gameStorage.FileExists(AlienShooterStateFileName))
        {
          gameStorage.DeleteFile(AlienShooterStateFileName);
        }
        if (!statusBoard.GameOver)
        {
          using (IsolatedStorageFileStream fs =
            gameStorage.OpenFile(AlienShooterStateFileName,
                                 System.IO.FileMode.Create))
          {
            using (StreamWriter streamWriter = new StreamWriter(fs))
            {
              //Only serialize interesting state
              //Other state MUST be initialized each time
              streamWriter.WriteLine(heroShip.Position.X);
              streamWriter.WriteLine(heroShip.Position.Y);
              streamWriter.WriteLine(heroShip.Velocity.X);
              streamWriter.WriteLine(heroShip.Velocity.Y);
              streamWriter.WriteLine(statusBoard.Score);
              streamWriter.WriteLine(statusBoard.Lives);
              for (int i = 0; i < maxEnemies; i++)
              {
                streamWriter.WriteLine(enemies[i].Alive);
                streamWriter.WriteLine(enemies[i].Position.X);
                streamWriter.WriteLine(enemies[i].Position.Y);
                streamWriter.WriteLine(enemies[i].Velocity.X);
                streamWriter.WriteLine(enemies[i].Velocity.Y);
              }
              streamWriter.Flush();
              streamWriter.Close();
            }
          }
        }
      }
    }

    public void LoadAlienShooterState(string startState)
    {
      using (IsolatedStorageFile gameStorage = IsolatedStorageFile.GetUserStoreForApplication())
      {
        //Initialize all objects as before
        enemies = new List<AlienGameObject>();
        for (int i = 0; i < maxEnemies; i++)
        {
          enemies.Add(new AlienGameObject(alienShooterSpriteSheet, "spaceship", screenRect));
        }

        //Initialize Player Object
        heroShip = new UserGameObject(alienShooterSpriteSheet, "heroship", screenRect, maxMissiles);
        heroShip.Position = new Vector2(screenRect.Width / 2, 720);
        heroShip.LoadContent(contentManager);

        //Initialize Status Board
        statusBoard = new GameStatusBoard(HUDGrid,SharedGraphicsDeviceManager.Current.GraphicsDevice.Viewport.Width, 26);
        statusBoard.LoadContent(contentManager);

        //Set saved state on objects if saved state is available and user selects resume
        if ((gameStorage.FileExists(AlienShooterStateFileName)) &&
            (startState == "resume"))
        {
          using (IsolatedStorageFileStream fs =
          gameStorage.OpenFile(AlienShooterStateFileName, System.IO.FileMode.Open))
          {
            using (StreamReader streamReader = new StreamReader(fs))
            {
              heroShip.Position = new Vector2(
                (float)Convert.ToDouble(streamReader.ReadLine()),
                (float)Convert.ToDouble(streamReader.ReadLine()));
              heroShip.Velocity = new Vector2(
                (float)Convert.ToDouble(streamReader.ReadLine()),
                (float)Convert.ToDouble(streamReader.ReadLine()));
              statusBoard.Score = Convert.ToInt32(streamReader.ReadLine());
              statusBoard.Lives = Convert.ToInt32(streamReader.ReadLine());
              for (int i = 0; i < maxEnemies; i++)
              {
                enemies[i].Alive = Convert.ToBoolean(streamReader.ReadLine());
                enemies[i].Position = new Vector2(
                  (float)Convert.ToDouble(streamReader.ReadLine()),
                  (float)Convert.ToDouble(streamReader.ReadLine()));
                enemies[i].Velocity = new Vector2(
                  (float)Convert.ToDouble(streamReader.ReadLine()),
                  (float)Convert.ToDouble(streamReader.ReadLine()));
              }
              streamReader.Close();
            }
          }
        }
      }
    }
    #endregion
  }
}